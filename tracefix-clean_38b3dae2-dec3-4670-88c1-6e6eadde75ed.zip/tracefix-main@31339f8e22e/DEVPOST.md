# TraceFix — Devpost submission draft

## Tagline

Gemini-powered reliability copilot that debugs, fixes, and verifies agent improvements using Phoenix traces.

## Description

TraceFix is a Gemini-powered reliability copilot for agent teams. It connects a Google ADK task agent to Arize Phoenix using OpenInference tracing, then uses the Phoenix MCP server to inspect traces, spans, prompts, datasets, annotations, and experiments at runtime. When an agent fails, TraceFix classifies the failure, identifies root cause from trace evidence, proposes prompt or tool-routing changes, replays the failed execution, and **on human approval automatically applies the patch** to local runtime policy and Phoenix prompt versions, then re-runs verification.

## Features

- Support/refund demo agent with 5 instrumented tools + routing enforcement
- Phoenix Cloud tracing via OpenInference ADK instrumentation
- 4 evaluators: task success, groundedness, tool correctness, cost discipline
- TraceFix copilot queries Phoenix via MCP at runtime
- Replay loop with before/after score comparison and promotion guardrails
- **Auto-apply on promote**: local policy overlay + Phoenix `upsert-prompt` + verification run
- Regression dataset capture via Phoenix MCP
- Triage console with rollback support

## Demo

See **[DEMO_PLAN.md](DEMO_PLAN.md)** (live + submission) and **[VIDEO_SCRIPT.md](VIDEO_SCRIPT.md)** (≤ 3 min).

## Technologies

- Google ADK, Gemini 2.5 Flash
- Arize Phoenix, OpenInference, Phoenix MCP
- FastAPI, Cloud Run
