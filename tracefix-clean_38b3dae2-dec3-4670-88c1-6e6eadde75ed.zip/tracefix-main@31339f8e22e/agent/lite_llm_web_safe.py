"""ADK Web-safe LiteLlm for OpenAI-compatible gateways."""

from __future__ import annotations

from typing import Any

from google.adk.models.lite_llm import LiteLlm


class WebSafeLiteLlm(LiteLlm):
    """LiteLlm that omits non-JSON-serializable fields for ADK Web.

    ``adk web`` ``/dev/build_graph`` calls ``model_dump(mode="python")`` on the
    agent model. Upstream ``LiteLlm`` includes ``llm_client`` in that dump,
    which breaks graph rendering (google/adk-python#5367). This subclass drops
    ``llm_client`` from dumps until ADK ships the upstream fix.
    """

    def model_dump(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        data = super().model_dump(*args, **kwargs)
        data.pop("llm_client", None)
        return data
