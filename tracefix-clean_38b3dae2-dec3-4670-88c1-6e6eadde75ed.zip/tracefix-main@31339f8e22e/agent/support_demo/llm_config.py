"""Configure Gemini auth for Agent Engine deployment."""

from __future__ import annotations

import os
from typing import Union


def configure_llm_env() -> None:
    """Ensure env is set for direct Google API key mode."""
    if os.environ.get("GOOGLE_GENAI_USE_VERTEXAI", "0") not in ("1", "true", "True"):
        os.environ.setdefault("GOOGLE_GENAI_USE_VERTEXAI", "0")


def get_adk_agent_model() -> str:
    """Return the Gemini model string for ADK Agent(model=...)."""
    return (os.environ.get("GEMINI_MODEL") or "").strip() or "gemini-2.5-flash"
