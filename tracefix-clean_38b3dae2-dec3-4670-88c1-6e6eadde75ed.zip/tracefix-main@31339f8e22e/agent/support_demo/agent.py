import os
from pathlib import Path

from dotenv import load_dotenv
from google.adk.agents import Agent
from google.adk.tools import FunctionTool

from .instrumentation import setup_tracing
from .prompt import get_active_instruction
from .tools.customer_history import customer_history
from .tools.draft_response import draft_response
from .tools.eligibility_check import eligibility_check
from .tools.order_lookup import order_lookup
from .tools.policy_lookup import policy_lookup

_agent_dir = Path(__file__).resolve().parent
for _env_path in (_agent_dir / ".env", _agent_dir.parents[1] / ".env"):
    if _env_path.is_file():
        load_dotenv(_env_path)
        break

from .llm_config import configure_llm_env, get_adk_agent_model

configure_llm_env()
setup_tracing()

_model = get_adk_agent_model()

root_agent = Agent(
    model=_model,
    name="support_refund_agent",
    instruction=get_active_instruction(),
    tools=[
        FunctionTool(func=order_lookup),
        FunctionTool(func=policy_lookup),
        FunctionTool(func=customer_history),
        FunctionTool(func=eligibility_check),
        FunctionTool(func=draft_response),
    ],
)


def _patch_adkapp_session_service():
    """Monkey-patch AdkApp.set_up to use InMemorySessionService.

    Express Mode's VertexAiSessionService can't create sessions (returns 404
    "ReasoningEngine does not exist"). InMemorySessionService works for demos
    since both session create and query go through the same in-process instance.
    """
    try:
        from vertexai.agent_engines.templates.adk import AdkApp
        from google.adk.sessions import InMemorySessionService
        _original_set_up = AdkApp.set_up

        def _patched_set_up(self):
            _original_set_up(self)
            mem_svc = InMemorySessionService()
            self._tmpl_attrs["session_service"] = mem_svc
            runner = self._tmpl_attrs.get("runner")
            if runner:
                runner.session_service = mem_svc
                runner.auto_create_session = True

        AdkApp.set_up = _patched_set_up
    except Exception:
        pass


_patch_adkapp_session_service()
