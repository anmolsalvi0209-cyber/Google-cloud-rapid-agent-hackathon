"""Tracing setup for Agent Engine deployment.

On Agent Engine, Cloud Trace is handled by the platform (--otel_to_cloud).
This module provides a no-op setup to keep the agent code compatible.
"""

from __future__ import annotations

import os
from typing import Any, Optional

from opentelemetry import trace


def format_otel_trace_id(trace_id_int: int) -> str:
    return format(trace_id_int, "032x")


def current_otel_trace_id() -> Optional[str]:
    span = trace.get_current_span()
    ctx = span.get_span_context()
    if not ctx or not ctx.is_valid:
        return None
    return format_otel_trace_id(ctx.trace_id)


def setup_tracing(project_name: Optional[str] = None) -> Optional[Any]:
    """No-op on Agent Engine — platform handles Cloud Trace via --otel_to_cloud."""
    return None
