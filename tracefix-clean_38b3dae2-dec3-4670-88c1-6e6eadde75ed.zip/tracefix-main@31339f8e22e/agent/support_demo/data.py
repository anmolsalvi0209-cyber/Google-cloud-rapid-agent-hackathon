"""Load demo fixtures bundled within the package."""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures"


@lru_cache(maxsize=1)
def load_orders() -> dict:
    return json.loads((FIXTURES_DIR / "orders.json").read_text())


@lru_cache(maxsize=1)
def load_customers() -> dict:
    return json.loads((FIXTURES_DIR / "customers.json").read_text())


@lru_cache(maxsize=1)
def load_refund_policy() -> str:
    return (FIXTURES_DIR / "policies" / "refund_policy.md").read_text()
