from __future__ import annotations

import json

from ..span_helpers import business_span
from ..run_context import get_run_context
from ..tool_policy import assert_allowed


def draft_response(decision: str, evidence: str, order_id: str = "") -> str:
    """Draft the customer-facing refund response with required evidence citations.

    Args:
        decision: approve, deny, cancel_only, or clarify.
        evidence: Policy and order evidence supporting the decision.
        order_id: Optional order ID for the response header.

    Returns:
        Formatted customer response text.
    """
    violation = assert_allowed("draft_response")
    if violation:
        return json.dumps({"error": violation, "policy_violation": True})

    ctx = get_run_context()
    ctx.record_tool("draft_response")
    ctx.final_decision = decision

    with business_span("refund_decision", {"decision": decision, "order_id": order_id}):
        response = {
            "order_id": order_id,
            "decision": decision,
            "evidence": evidence,
            "message": (
                f"Regarding order {order_id}: we have {decision}d your refund request. "
                f"Evidence: {evidence}"
            ),
        }
        output = json.dumps(response, indent=2)
        ctx.agent_output = output
        return output
