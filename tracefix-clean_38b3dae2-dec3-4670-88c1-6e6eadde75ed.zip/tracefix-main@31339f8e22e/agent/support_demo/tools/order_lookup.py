from __future__ import annotations

import json

from ..span_helpers import business_span
from ..run_context import get_run_context
from ..data import load_orders


def order_lookup(order_id: str) -> str:
    """Look up order details by order ID.

    Args:
        order_id: Order identifier (e.g. ORD-1001).

    Returns:
        JSON string with order status, items, purchase date, and customer ID.
    """
    ctx = get_run_context()
    ctx.record_tool("order_lookup")

    with business_span("tool_route_chosen", {"tool": "order_lookup", "order_id": order_id}):
        orders = load_orders()
        order = orders.get(order_id.upper())
        if not order:
            return json.dumps({"error": f"Order {order_id} not found"})
        return json.dumps(order, indent=2)
