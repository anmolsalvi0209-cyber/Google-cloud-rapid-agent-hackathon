from __future__ import annotations

import json

from ..span_helpers import business_span
from ..run_context import get_run_context
from ..data import load_refund_policy
from ..tool_policy import assert_allowed


def policy_lookup(topic: str) -> str:
    """Retrieve refund policy text for a given topic.

    Args:
        topic: Policy topic such as 'refund', 'eligibility', or 'denial'.

    Returns:
        Relevant policy text from the official refund policy document.
    """
    violation = assert_allowed("policy_lookup")
    if violation:
        return json.dumps({"error": violation, "policy_violation": True})

    ctx = get_run_context()
    ctx.record_tool("policy_lookup")

    policy = load_refund_policy()
    topic_lower = topic.lower()

    with business_span("policy_evidence_selected", {"topic": topic}):
        ctx.policy_evidence.append(topic)

        if topic_lower in ("refund", "all", "policy"):
            return policy

        sections = []
        for line in policy.splitlines():
            if topic_lower in line.lower():
                sections.append(line)
        if sections:
            return "\n".join(sections)
        return f"No exact section for '{topic}'. Full policy:\n\n{policy}"
