from __future__ import annotations

import json

from ..span_helpers import business_span
from ..run_context import get_run_context
from ..data import load_orders
from ..tool_policy import assert_allowed


def eligibility_check(order_id: str, reason: str) -> str:
    """Deterministic refund eligibility check using order data and policy rules.

    Args:
        order_id: Order to evaluate.
        reason: Customer's stated refund reason.

    Returns:
        JSON with eligible (bool), decision, and policy citation.
    """
    violation = assert_allowed("eligibility_check")
    if violation:
        return json.dumps({"error": violation, "policy_violation": True})

    ctx = get_run_context()
    ctx.record_tool("eligibility_check")

    orders = load_orders()
    order = orders.get(order_id.upper())

    with business_span("refund_decision", {"order_id": order_id, "reason": reason}):
        if not order:
            result = {"eligible": False, "decision": "deny", "citation": "Order not found"}
        elif order["status"] != "delivered":
            result = {
                "eligible": False,
                "decision": "cancel_only",
                "citation": "Refund Policy: shipped-but-not-delivered — cancellation only",
            }
        elif order["days_since_delivery"] > 30:
            result = {
                "eligible": False,
                "decision": "deny",
                "citation": "Refund Policy: orders older than 30 days",
            }
        elif "defective" in reason.lower() or "wrong item" in reason.lower():
            result = {
                "eligible": True,
                "decision": "approve",
                "citation": "Refund Policy: defective or wrong item — full refund within 30 days",
            }
        else:
            result = {
                "eligible": True,
                "decision": "approve",
                "citation": "Refund Policy: changed mind — unopened within 30 days",
            }

        ctx.final_decision = result["decision"]
        return json.dumps(result, indent=2)
