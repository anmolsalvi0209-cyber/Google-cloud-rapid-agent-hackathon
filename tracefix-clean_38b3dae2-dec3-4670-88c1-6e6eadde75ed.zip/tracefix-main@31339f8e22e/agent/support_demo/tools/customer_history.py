from __future__ import annotations

import json

from ..span_helpers import business_span
from ..run_context import get_run_context
from ..data import load_customers
from ..tool_policy import assert_allowed


def customer_history(customer_id: str) -> str:
    """Fetch customer refund and dispute history.

    Args:
        customer_id: Customer identifier (e.g. CUST-42).

    Returns:
        JSON with prior refunds, disputes, and account tier.
    """
    violation = assert_allowed("customer_history")
    if violation:
        return json.dumps({"error": violation, "policy_violation": True})

    ctx = get_run_context()
    ctx.record_tool("customer_history")

    with business_span("tool_route_chosen", {"tool": "customer_history", "customer_id": customer_id}):
        customers = load_customers()
        customer = customers.get(customer_id.upper())
        if not customer:
            return json.dumps({"error": f"Customer {customer_id} not found"})
        return json.dumps(customer, indent=2)
