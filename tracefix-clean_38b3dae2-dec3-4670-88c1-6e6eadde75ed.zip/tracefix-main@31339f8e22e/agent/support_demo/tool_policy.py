"""Enforce tool routing rules from active policy."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional

from .run_context import get_run_context


def _routing_path() -> Path:
    data_dir = Path(os.environ.get("TRACEFIX_DATA_DIR", ""))
    if not data_dir or not data_dir.is_absolute():
        return Path(__file__).resolve().parent / "fixtures" / "tool_routing.json"
    return data_dir / "active_policy" / "tool_routing.json"


def load_routing_rules() -> dict[str, Any]:
    path = _routing_path()
    if path.exists():
        return json.loads(path.read_text())
    return {
        "required_before": {
            "customer_history": ["order_lookup"],
            "eligibility_check": ["order_lookup", "policy_lookup"],
            "draft_response": ["order_lookup", "policy_lookup"],
        },
    }


def assert_allowed(tool_name: str) -> Optional[str]:
    """Return error message if tool violates routing policy, else None."""
    ctx = get_run_context()
    rules = load_routing_rules()
    required_before: dict[str, list[str]] = rules.get("required_before", {})
    prerequisites = required_before.get(tool_name, [])
    if not prerequisites:
        return None

    seq = ctx.tool_sequence
    for req in prerequisites:
        if req not in seq:
            return (
                f"Tool routing policy violation: `{tool_name}` requires `{req}` "
                f"to be called first. Current sequence: {seq or 'empty'}."
            )
    return None
