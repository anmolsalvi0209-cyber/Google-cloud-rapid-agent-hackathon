"""Per-run context for tool sequencing, cost tracking, and eval inputs."""

from __future__ import annotations

import contextvars
import time
from dataclasses import dataclass, field
from typing import Optional

_run_context: contextvars.ContextVar[Optional["RunContext"]] = contextvars.ContextVar(
    "run_context", default=None
)


@dataclass
class RunContext:
    trace_id: str = ""
    session_id: str = ""
    failure_seed_id: Optional[str] = None
    user_input: str = ""
    agent_output: str = ""
    tool_sequence: list[str] = field(default_factory=list)
    model_calls: int = 0
    token_count: int = 0
    start_time: float = field(default_factory=time.time)
    policy_evidence: list[str] = field(default_factory=list)
    final_decision: str = ""

    @property
    def latency_ms(self) -> float:
        return (time.time() - self.start_time) * 1000

    @property
    def estimated_cost(self) -> float:
        return round(self.token_count * 0.00000015, 6)

    def record_tool(self, name: str) -> None:
        self.tool_sequence.append(name)

    def add_tokens(self, count: int) -> None:
        self.model_calls += 1
        self.token_count += count


def get_run_context() -> RunContext:
    ctx = _run_context.get()
    if ctx is None:
        ctx = RunContext()
        _run_context.set(ctx)
    return ctx


def set_run_context(ctx: RunContext) -> None:
    _run_context.set(ctx)


def clear_run_context() -> None:
    _run_context.set(None)
