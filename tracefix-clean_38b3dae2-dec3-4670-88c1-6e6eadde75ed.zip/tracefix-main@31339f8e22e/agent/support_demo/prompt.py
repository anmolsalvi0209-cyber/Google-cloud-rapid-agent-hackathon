"""System instruction for the support/refund task agent."""

from __future__ import annotations

import os
from pathlib import Path

support_refund_agent_instruction = """You are a customer support refund agent. Help customers with refund requests using the provided tools.

**Required workflow (follow in order):**

1. **order_lookup** — Always look up the order first using the order ID from the request.
2. **policy_lookup** — Always retrieve refund policy before making any eligibility decision. Topic: "refund".
3. **customer_history** — Optional; use only after order lookup if account history is relevant.
4. **eligibility_check** — Run deterministic eligibility when you have order ID and reason.
5. **draft_response** — Produce the final customer response with decision and evidence citations.

**Rules:**
- Never approve or deny a refund without calling `policy_lookup` first.
- Cite specific policy sections and order facts in every final response.
- If the request is ambiguous (e.g. unclear damage description), ask a clarifying question instead of assuming.
- Use `eligibility_check` for straightforward cases to avoid unnecessary reasoning loops.
- Keep responses concise and professional.

**Evidence requirement:** Every `draft_response` must include evidence from `policy_lookup` and `order_lookup` outputs.
"""


_REPO_ROOT = Path(__file__).resolve().parents[2]  # agent/support_demo/prompt.py → repo root


def _overlay_path() -> Path:
    data_dir_env = os.environ.get("TRACEFIX_DATA_DIR", "")
    if data_dir_env:
        data_dir = Path(data_dir_env)
        if not data_dir.is_absolute():
            data_dir = _REPO_ROOT / data_dir  # resolve relative paths from repo root
        return data_dir / "active_policy" / "instruction_overlay.md"
    return Path(__file__).resolve().parent / "fixtures" / "instruction_overlay.md"


def read_overlay_if_exists() -> str:
    path = _overlay_path()
    if path.exists():
        return path.read_text().strip()
    return ""


def get_active_instruction() -> str:
    base = support_refund_agent_instruction
    overlay = read_overlay_if_exists()
    if overlay:
        return f"{base}\n\n## Active patches\n{overlay}"
    return base
