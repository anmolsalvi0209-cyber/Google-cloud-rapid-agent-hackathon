from __future__ import annotations

import secrets
from typing import Any, Optional

from evals.runner import evaluate_run
from models import PatchProposal, PromotionStatus, ReplayResult
from replay.promotion import evaluate_promotion
from run_context import RunContext, clear_run_context, set_run_context


def _simulate_patched_run(
    baseline_ctx: RunContext,
    patch: PatchProposal,
) -> RunContext:
    """Simulate improved behavior after applying a patch (for demo/replay without live LLM)."""
    patched = RunContext(
        trace_id=f"patched-{secrets.token_hex(4)}",
        session_id=baseline_ctx.session_id,
        user_input=baseline_ctx.user_input,
        failure_seed_id=baseline_ctx.failure_seed_id,
    )

    seq = list(baseline_ctx.tool_sequence)

    if patch.patch_type.value == "tool_routing" and "wrong_tool_route" in (
        baseline_ctx.failure_seed_id or ""
    ):
        # Reorder: ensure order_lookup before customer_history
        if "customer_history" in seq and "order_lookup" in seq:
            seq.remove("order_lookup")
            idx = seq.index("customer_history")
            seq.insert(idx, "order_lookup")

    if patch.patch_type.value == "prompt" or "hallucinated" in (baseline_ctx.failure_seed_id or ""):
        if "policy_lookup" not in seq:
            insert_at = seq.index("draft_response") if "draft_response" in seq else len(seq)
            seq.insert(insert_at, "policy_lookup")
            patched.policy_evidence.append("refund")

    if patch.patch_type.value == "prompt" and "cost" in (baseline_ctx.failure_seed_id or ""):
        if "eligibility_check" not in seq:
            seq.insert(-1 if seq else 0, "eligibility_check")
        patched.model_calls = max(1, baseline_ctx.model_calls // 2)
        patched.token_count = max(500, baseline_ctx.token_count // 2)
    else:
        patched.model_calls = baseline_ctx.model_calls
        patched.token_count = baseline_ctx.token_count

    patched.tool_sequence = seq
    patched.final_decision = baseline_ctx.final_decision or "approve"
    patched.agent_output = baseline_ctx.agent_output
    return patched


def run_replay_comparison(
    baseline_ctx: RunContext,
    patch: PatchProposal,
    expected_decision: Optional[str] = None,
) -> ReplayResult:
    """Compare baseline vs patched run using evaluators."""
    baseline_eval = evaluate_run(baseline_ctx, expected_decision)

    patched_ctx = _simulate_patched_run(baseline_ctx, patch)
    set_run_context(patched_ctx)
    patched_eval = evaluate_run(patched_ctx, expected_decision)
    clear_run_context()

    score_delta = {
        k: round(patched_eval["scores"][k] - baseline_eval["scores"][k], 3)
        for k in baseline_eval["scores"]
    }

    result = ReplayResult(
        baseline_trace_id=baseline_ctx.trace_id,
        patched_run_id=patched_ctx.trace_id,
        dataset_id=f"regression-{baseline_ctx.trace_id[:8]}",
        experiment_id=f"exp-{secrets.token_hex(4)}",
        baseline_scores=baseline_eval["scores"],
        patched_scores=patched_eval["scores"],
        score_delta=score_delta,
        cost_delta=round(patched_ctx.estimated_cost - baseline_ctx.estimated_cost, 6),
        latency_delta_ms=round(patched_ctx.latency_ms - baseline_ctx.latency_ms, 2),
    )
    result.promotion_status = evaluate_promotion(result)
    return result


def build_patch_for_failure(failure_type: str, trace_id: str) -> PatchProposal:
    """Generate a default patch proposal from failure classification."""
    patches: dict[str, dict[str, Any]] = {
        "hallucination": {
            "patch_type": "prompt",
            "target": "support_refund_agent_instruction",
            "diff": "Require policy_lookup before any refund decision; add evidence field.",
            "content": "NEVER approve/deny without policy_lookup. Include evidence citations.",
        },
        "wrong_tool_route": {
            "patch_type": "tool_routing",
            "target": "tool_policy",
            "diff": "Enforce order_lookup before customer_history and eligibility_check.",
            "content": "ROUTING: order_lookup -> policy_lookup -> customer_history (optional) -> eligibility_check -> draft_response",
        },
        "cost_spike": {
            "patch_type": "prompt",
            "target": "support_refund_agent_instruction",
            "diff": "Use eligibility_check for straightforward cases; avoid reasoning loops.",
            "content": "Call eligibility_check early. Do not re-summarize order fields multiple times.",
        },
    }
    p = patches.get(failure_type, patches["hallucination"])
    from models import PatchType

    return PatchProposal(
        trace_id=trace_id,
        patch_type=PatchType(p["patch_type"]),
        target_prompt_or_tool=p["target"],
        diff_summary=p["diff"],
        patched_content=p["content"],
        risk_level="low",
        expected_metric_change={"groundedness": "+0.5", "cost_discipline": "+0.3"},
    )
