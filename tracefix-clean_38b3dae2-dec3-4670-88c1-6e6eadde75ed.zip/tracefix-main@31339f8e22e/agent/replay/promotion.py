from __future__ import annotations

from models import PromotionStatus, ReplayResult


def evaluate_promotion(
    replay: ReplayResult,
    min_score_improvement: float = 0.1,
    max_cost_regression: float = 0.2,
    max_latency_regression_ms: float = 5000,
) -> PromotionStatus:
    """Decide if a patch is ready for promotion based on score/cost/latency deltas."""
    if not replay.score_delta:
        return PromotionStatus.PENDING

    avg_improvement = sum(replay.score_delta.values()) / len(replay.score_delta)
    if avg_improvement < min_score_improvement:
        return PromotionStatus.REJECTED

    if replay.cost_delta > max_cost_regression:
        return PromotionStatus.REJECTED

    if replay.latency_delta_ms > max_latency_regression_ms:
        return PromotionStatus.REJECTED

    return PromotionStatus.READY
