"""Manual OpenTelemetry spans for business decisions."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator, Optional

from opentelemetry import trace

from run_context import get_run_context

_tracer = trace.get_tracer("tracefix.support")


@contextmanager
def business_span(
    name: str,
    attributes: Optional[dict[str, Any]] = None,
) -> Generator[trace.Span, None, None]:
    ctx = get_run_context()
    attrs = dict(attributes or {})
    if ctx.failure_seed_id:
        attrs["failure_seed_id"] = ctx.failure_seed_id
    attrs["model_calls"] = ctx.model_calls
    attrs["token_count"] = ctx.token_count
    with _tracer.start_as_current_span(name) as span:
        for key, value in attrs.items():
            span.set_attribute(key, value)
        yield span
