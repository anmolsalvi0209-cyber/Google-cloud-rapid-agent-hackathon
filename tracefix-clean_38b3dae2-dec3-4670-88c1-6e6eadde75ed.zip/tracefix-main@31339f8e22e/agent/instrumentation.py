"""Phoenix tracing via phoenix.otel.register with auto-instrumentation."""

from __future__ import annotations

import os
from typing import Any, Optional

from opentelemetry import trace
from phoenix.otel import register

_provider: Optional[Any] = None


def format_otel_trace_id(trace_id_int: int) -> str:
    """OpenTelemetry / Phoenix trace id (32 lowercase hex chars)."""
    return format(trace_id_int, "032x")


def current_otel_trace_id() -> Optional[str]:
    span = trace.get_current_span()
    ctx = span.get_span_context()
    if not ctx or not ctx.is_valid:
        return None
    return format_otel_trace_id(ctx.trace_id)


def build_phoenix_trace_url(trace_id: str, project_name: Optional[str] = None) -> str:
    """Deep link into Phoenix UI (uses space slug from PHOENIX_COLLECTOR_ENDPOINT when set)."""
    project = project_name or os.environ.get("PHOENIX_PROJECT_NAME", "tracefix-support-agent")
    base = (
        os.environ.get("PHOENIX_COLLECTOR_ENDPOINT")
        or os.environ.get("PHOENIX_UI_BASE_URL")
        or "https://app.phoenix.arize.com"
    ).rstrip("/")
    return f"{base}/projects/{project}/traces/{trace_id}"


def _phoenix_configured() -> bool:
    """True when either an API key (cloud) or a collector endpoint (local) is set."""
    return bool(
        (os.environ.get("PHOENIX_API_KEY") or "").strip()
        or (os.environ.get("PHOENIX_COLLECTOR_ENDPOINT") or "").strip()
    )


def setup_tracing(project_name: Optional[str] = None) -> Optional[Any]:
    """Returns the tracer provider when Phoenix is configured, else None."""
    global _provider
    if _provider is not None:
        return _provider  # avoid TracerProvider override warnings in shared processes
    if not _phoenix_configured():
        return None
    kwargs: dict = dict(
        project_name=project_name or os.environ.get("PHOENIX_PROJECT_NAME", "tracefix-support-agent"),
        batch=False,
        auto_instrument=True,
        verbose=False,
    )
    # When using a local Phoenix instance the endpoint must be passed explicitly;
    # otherwise phoenix.otel defaults to gRPC on port 4317.
    collector_endpoint = (os.environ.get("PHOENIX_COLLECTOR_ENDPOINT") or "").strip()
    if collector_endpoint and not (os.environ.get("PHOENIX_API_KEY") or "").strip():
        kwargs["endpoint"] = collector_endpoint.rstrip("/") + "/v1/traces"
    _provider = register(**kwargs)
    return _provider
