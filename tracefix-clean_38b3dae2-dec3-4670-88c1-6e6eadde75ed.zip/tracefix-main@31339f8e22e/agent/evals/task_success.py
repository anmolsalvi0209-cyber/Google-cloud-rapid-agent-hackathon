from __future__ import annotations

from run_context import RunContext


def eval_task_success(ctx: RunContext, expected_decision: str | None = None) -> tuple[float, str]:
    """Score whether the final decision matches expectations."""
    if not ctx.final_decision:
        return 0.0, "No final decision recorded"

    if expected_decision and ctx.final_decision != expected_decision:
        return 0.2, f"Expected decision '{expected_decision}', got '{ctx.final_decision}'"

    if ctx.final_decision in ("approve", "deny", "cancel_only", "clarify"):
        return 1.0, f"Valid decision: {ctx.final_decision}"
    return 0.5, f"Unclear decision: {ctx.final_decision}"
