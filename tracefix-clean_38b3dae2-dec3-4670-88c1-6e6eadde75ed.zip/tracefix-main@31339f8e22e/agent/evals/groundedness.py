from __future__ import annotations

from run_context import RunContext


def eval_groundedness(ctx: RunContext) -> tuple[float, str]:
    """Check that policy evidence was retrieved before a refund decision."""
    has_policy = "policy_lookup" in ctx.tool_sequence
    has_order = "order_lookup" in ctx.tool_sequence
    has_evidence = bool(ctx.policy_evidence) or has_policy

    if ctx.final_decision in ("approve", "deny") and not has_policy:
        return 0.0, "Refund decision made without policy_lookup — unsupported claim risk"

    if not has_order:
        return 0.3, "Missing order_lookup before decision"

    if has_evidence and has_order:
        return 1.0, "Decision grounded in policy and order data"

    return 0.6, "Partial grounding — policy or order evidence incomplete"
