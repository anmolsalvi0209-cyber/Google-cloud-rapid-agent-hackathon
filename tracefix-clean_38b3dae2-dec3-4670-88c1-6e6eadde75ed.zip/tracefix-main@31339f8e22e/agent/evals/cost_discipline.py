from __future__ import annotations

import os

from run_context import RunContext


def eval_cost_discipline(ctx: RunContext) -> tuple[float, str]:
    """Check model call count, token budget, and latency thresholds."""
    max_calls = int(os.environ.get("EVAL_MAX_MODEL_CALLS", "8"))
    max_tokens = int(os.environ.get("EVAL_MAX_TOKENS", "8000"))
    max_latency = float(os.environ.get("EVAL_MAX_LATENCY_MS", "30000"))

    issues = []
    score = 1.0

    if ctx.model_calls > max_calls:
        score -= 0.4
        issues.append(f"model calls {ctx.model_calls} > {max_calls}")

    if ctx.token_count > max_tokens:
        score -= 0.3
        issues.append(f"tokens {ctx.token_count} > {max_tokens}")

    if ctx.latency_ms > max_latency:
        score -= 0.2
        issues.append(f"latency {ctx.latency_ms:.0f}ms > {max_latency:.0f}ms")

    if issues:
        return max(0.0, score), "; ".join(issues)
    return 1.0, f"Within budget: {ctx.model_calls} calls, {ctx.token_count} tokens, {ctx.latency_ms:.0f}ms"
