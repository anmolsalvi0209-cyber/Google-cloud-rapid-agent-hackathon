from __future__ import annotations

from run_context import RunContext

REQUIRED_PREFIX = ["order_lookup", "policy_lookup"]


def eval_tool_correctness(ctx: RunContext) -> tuple[float, str]:
    """Verify required tools were called in the expected order."""
    seq = ctx.tool_sequence
    if not seq:
        return 0.0, "No tools called"

    # order_lookup must come before customer_history and draft_response
    if "customer_history" in seq and "order_lookup" in seq:
        if seq.index("customer_history") < seq.index("order_lookup"):
            return 0.0, "customer_history called before order_lookup — wrong tool route"

    if "draft_response" in seq:
        if "order_lookup" not in seq:
            return 0.2, "draft_response without order_lookup"
        if seq.index("order_lookup") > seq.index("draft_response"):
            return 0.0, "order_lookup after draft_response — wrong sequence"

    for i, tool in enumerate(REQUIRED_PREFIX):
        if tool not in seq:
            return 0.3, f"Missing required tool: {tool}"
        if seq.index(tool) > (seq.index("draft_response") if "draft_response" in seq else len(seq)):
            return 0.0, f"{tool} called too late in workflow"

    if seq.index("order_lookup") > seq.index("policy_lookup"):
        # order before policy is OK; policy must exist before draft
        pass

    if "draft_response" in seq and "policy_lookup" in seq:
        if seq.index("policy_lookup") > seq.index("draft_response"):
            return 0.0, "policy_lookup after draft_response — hallucination risk"

    return 1.0, f"Tool sequence valid: {' -> '.join(seq)}"
