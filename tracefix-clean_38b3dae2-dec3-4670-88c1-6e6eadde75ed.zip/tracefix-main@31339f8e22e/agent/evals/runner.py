from __future__ import annotations

from typing import Any

from evals.cost_discipline import eval_cost_discipline
from evals.groundedness import eval_groundedness
from evals.task_success import eval_task_success
from evals.tool_correctness import eval_tool_correctness
from models import FailureType, TraceStatus
from run_context import RunContext


def evaluate_run(
    ctx: RunContext,
    expected_decision: str | None = None,
) -> dict[str, Any]:
    """Run all evaluators and return structured scores + failure labels."""
    results: dict[str, tuple[float, str]] = {
        "task_success": eval_task_success(ctx, expected_decision),
        "groundedness": eval_groundedness(ctx),
        "tool_correctness": eval_tool_correctness(ctx),
        "cost_discipline": eval_cost_discipline(ctx),
    }

    scores = {name: score for name, (score, _) in results.items()}
    explanations = {name: expl for name, (_, expl) in results.items()}
    avg_score = sum(scores.values()) / len(scores) if scores else 0.0

    failure_labels: list[str] = []
    failure_type = FailureType.UNKNOWN

    if scores["groundedness"] < 0.5:
        failure_labels.append("hallucination")
        failure_type = FailureType.HALLUCINATION
    if scores["tool_correctness"] < 0.5:
        failure_labels.append("wrong_tool_route")
        failure_type = FailureType.WRONG_TOOL_ROUTE
    if scores["cost_discipline"] < 0.7:
        failure_labels.append("cost_spike")
        if failure_type == FailureType.UNKNOWN:
            failure_type = FailureType.COST_SPIKE
    if scores["task_success"] < 0.5:
        failure_labels.append("task_failure")

    status = TraceStatus.PASSED if avg_score >= 0.75 and not failure_labels else TraceStatus.FAILED

    return {
        "scores": scores,
        "explanations": explanations,
        "avg_score": round(avg_score, 3),
        "failure_labels": failure_labels,
        "failure_type": failure_type.value,
        "status": status.value,
    }
