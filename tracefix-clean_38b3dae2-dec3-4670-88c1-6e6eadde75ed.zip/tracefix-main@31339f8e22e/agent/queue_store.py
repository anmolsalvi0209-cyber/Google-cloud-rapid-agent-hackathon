"""Persist triage queue, assessments, patches, and replay results."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

from models import (
    DecisionLog,
    FailureAssessment,
    FailureType,
    PatchProposal,
    ReplayResult,
    TraceSummary,
    TriageQueue,
)

_REPO_ROOT = Path(__file__).resolve().parent.parent
_data_dir = Path(os.environ.get("TRACEFIX_DATA_DIR", "./data"))
DATA_DIR = _data_dir if _data_dir.is_absolute() else (_REPO_ROOT / _data_dir)
QUEUE_FILE = DATA_DIR / "triage_queue.json"


def _ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _phoenix_configured() -> bool:
    return bool(
        (os.environ.get("PHOENIX_API_KEY") or "").strip()
        or (os.environ.get("PHOENIX_COLLECTOR_ENDPOINT") or "").strip()
    )


def load_queue() -> TriageQueue:
    _ensure_data_dir()
    if QUEUE_FILE.exists():
        return TriageQueue.model_validate_json(QUEUE_FILE.read_text())
    demo_mode = os.environ.get("TRACEFIX_DEMO_MODE", "0") == "1"
    if demo_mode or not _phoenix_configured():
        return _load_cached_demo_queue()
    return TriageQueue(mode="live")


def _load_cached_demo_queue() -> TriageQueue:
    cached = Path(__file__).resolve().parent / "demo" / "cached_traces.json"
    if cached.exists():
        return TriageQueue.model_validate_json(cached.read_text())
    return TriageQueue(mode="demo")


def save_queue(queue: TriageQueue) -> None:
    _ensure_data_dir()
    QUEUE_FILE.write_text(queue.model_dump_json(indent=2))


def purge_demo_seed_traces() -> list[str]:
    """Remove demo seed rows (and related artifacts) before re-seeding."""
    from demo.trace_ids import DEMO_SEED_IDS

    queue = load_queue()
    removed_ids: list[str] = []
    keep: list[TraceSummary] = []
    for t in queue.traces:
        if t.failure_seed_id in DEMO_SEED_IDS or (
            t.trace_id.startswith("seed-") and t.trace_id.removeprefix("seed-") in DEMO_SEED_IDS
        ):
            removed_ids.append(t.trace_id)
        else:
            keep.append(t)
    if not removed_ids:
        return removed_ids
    queue.traces = keep
    for tid in removed_ids:
        queue.assessments.pop(tid, None)
        queue.patches.pop(tid, None)
        queue.replays.pop(tid, None)
        queue.decisions.pop(tid, None)
    save_queue(queue)
    return removed_ids


def upsert_trace(trace: TraceSummary) -> None:
    queue = load_queue()
    queue.traces = [t for t in queue.traces if t.trace_id != trace.trace_id]
    queue.traces.insert(0, trace)
    save_queue(queue)


def upsert_assessment(assessment: FailureAssessment) -> None:
    queue = load_queue()
    queue.assessments[assessment.trace_id] = assessment
    save_queue(queue)


def upsert_patch(patch: PatchProposal) -> None:
    queue = load_queue()
    queue.patches[patch.trace_id] = patch
    save_queue(queue)


def upsert_replay(replay: ReplayResult) -> None:
    queue = load_queue()
    queue.replays[replay.baseline_trace_id] = replay
    save_queue(queue)


def upsert_decision(decision: DecisionLog) -> None:
    queue = load_queue()
    queue.decisions[decision.trace_id] = decision
    save_queue(queue)


def get_trace(trace_id: str) -> Optional[TraceSummary]:
    queue = load_queue()
    for t in queue.traces:
        if t.trace_id == trace_id:
            return t
    return None


def build_assessment_from_eval(trace_id: str, eval_result: dict, tool_sequence: list[str]) -> FailureAssessment:
    failure_type = FailureType(eval_result.get("failure_type", "unknown"))
    explanations = eval_result.get("explanations", {})
    rca_parts = [f"{k}: {v}" for k, v in explanations.items() if eval_result["scores"].get(k, 1) < 0.75]
    return FailureAssessment(
        trace_id=trace_id,
        failure_type=failure_type,
        confidence=0.85 if eval_result.get("failure_labels") else 0.5,
        evidence_spans=tool_sequence,
        evaluator_scores=eval_result.get("scores", {}),
        natural_language_rca="; ".join(rca_parts) or "No significant failures detected.",
    )
