"""Phoenix MCP toolset configuration for the TraceFix copilot."""

from __future__ import annotations

import os
import shutil

from google.adk.tools.mcp_tool import McpToolset
from google.adk.tools.mcp_tool.mcp_session_manager import StdioConnectionParams
from mcp import StdioServerParameters

READ_TOOLS = [
    "list-traces",
    "get-trace",
    "get-spans",
    "get-span-annotations",
    "list-experiments-for-dataset",
    "get-experiment-by-id",
    "get-latest-prompt",
    "list-prompts",
    "list-projects",
    "list-datasets",
]

WRITE_TOOLS = [
    "add-dataset-examples",
    "upsert-prompt",
]

COPILOT_TOOL_FILTER = READ_TOOLS + WRITE_TOOLS

_mcp_toolset: McpToolset | None = None


def _phoenix_base_url() -> str:
    return (
        os.environ.get("PHOENIX_COLLECTOR_ENDPOINT")
        or os.environ.get("PHOENIX_BASE_URL")
        or "https://app.phoenix.arize.com"
    )


def _resolve_mcp_command() -> tuple[str, list[str]]:
    command = os.environ.get("TRACEFIX_MCP_COMMAND", "npx")
    custom_args = os.environ.get("TRACEFIX_MCP_ARGS", "").strip()
    if custom_args:
        return command, custom_args.split()

    api_key = os.environ.get("PHOENIX_API_KEY", "")
    base_url = _phoenix_base_url()
    # Match agent/apply/phoenix_mcp_client.py: explicit peers avoid broken npx trees;
    # cold npx can exceed ADK's default 5s MCP handshake without a longer timeout below.
    return command, [
        "-y",
        "-p",
        "ajv@8",
        "-p",
        "zod-to-json-schema@3",
        "-p",
        "@arizeai/phoenix-mcp@latest",
        "phoenix-mcp",
        "--baseUrl",
        base_url,
        "--apiKey",
        api_key,
    ]


def create_phoenix_mcp_toolset() -> McpToolset:
    """Create (or return cached) ADK McpToolset connected to @arizeai/phoenix-mcp."""
    global _mcp_toolset
    if _mcp_toolset is not None:
        return _mcp_toolset

    if not shutil.which(os.environ.get("TRACEFIX_MCP_COMMAND", "npx")):
        raise RuntimeError("npx not found on PATH — install Node.js 18+ for Phoenix MCP")

    api_key = os.environ.get("PHOENIX_API_KEY", "")
    base_url = _phoenix_base_url()
    command, args = _resolve_mcp_command()

    env = {
        **os.environ,
        "PHOENIX_API_KEY": api_key,
        "PHOENIX_HOST": base_url,
    }

    init_timeout = float(os.environ.get("TRACEFIX_MCP_INIT_TIMEOUT_SEC", "60"))
    _mcp_toolset = McpToolset(
        connection_params=StdioConnectionParams(
            server_params=StdioServerParameters(
                command=command,
                args=args,
                env=env,
            ),
            timeout=init_timeout,
        ),
        tool_filter=COPILOT_TOOL_FILTER,
    )
    return _mcp_toolset
