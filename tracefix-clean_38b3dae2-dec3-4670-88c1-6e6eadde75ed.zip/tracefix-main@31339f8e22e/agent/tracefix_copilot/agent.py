import os
from pathlib import Path

from dotenv import load_dotenv
from google.adk.agents import Agent
from google.adk.tools import FunctionTool

from tracefix_copilot.apply_tools import apply_support_agent_patch, get_triage_patch_for_trace
from tracefix_copilot.mcp_config import create_phoenix_mcp_toolset
from tracefix_copilot.prompt import tracefix_copilot_instruction

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from llm_config import configure_llm_env, get_adk_agent_model

configure_llm_env()

# Copilot tracing uses a separate Phoenix project; skip if support agent already registered.
if os.environ.get("PHOENIX_API_KEY") and not os.environ.get("TRACEFIX_SKIP_COPILOT_TRACING"):
    from instrumentation import setup_tracing

    setup_tracing(
        project_name=os.environ.get("PHOENIX_COPILOT_PROJECT", "tracefix-copilot"),
    )

_model = get_adk_agent_model()

_local_tools = [
    FunctionTool(func=apply_support_agent_patch),
    FunctionTool(func=get_triage_patch_for_trace),
]
_tools: list = list(_local_tools)
try:
    _tools.append(create_phoenix_mcp_toolset())
except RuntimeError:
    pass

_prompt_name = os.environ.get("TRACEFIX_PROMPT_NAME", "tracefix/support_refund_agent")
_copilot_instruction = (
    tracefix_copilot_instruction
    + f"\n\n**Configured support-agent prompt identifier:** `{_prompt_name}` — the ONLY default for "
    f"`get-latest-prompt`, `upsert-prompt`, and Phoenix prompt writes.\n"
    "**Triage console:** http://localhost:8080 — Replay + Promote also apply patches with human approval.\n"
)

root_agent = Agent(
    model=_model,
    name="tracefix_copilot",
    instruction=_copilot_instruction,
    tools=_tools,
)
