"""ADK function tools so the copilot can apply patches for real (not imaginary config files)."""

from __future__ import annotations

import os
import secrets
from typing import Any

from apply.patcher import apply_patch
from apply.phoenix_mcp_client import add_regression_example
from models import PatchProposal, PatchType
from queue_store import get_trace, load_queue


def apply_support_agent_patch(
    trace_id: str,
    diff_summary: str,
    patched_content: str,
    patch_type: str = "prompt",
    version_tag: str = "",
) -> dict[str, Any]:
    """Apply an approved patch to local TraceFix policy and upsert the merged prompt to Phoenix.

    Use after investigation when the user says apply / go ahead / promote.
    For prompt patches, `patched_content` is the new instruction text to append to the active overlay
    (or the full replacement block described in `diff_summary`).

    Args:
        trace_id: Phoenix / triage trace id this patch addresses (32-char hex).
        diff_summary: Short human-readable summary of what changed.
        patched_content: Prompt overlay text or tool-routing rule text.
        patch_type: One of: prompt, tool_routing.
        version_tag: Optional version label (default auto-generated).

    Returns:
        Apply result with version_tag, phoenix_status, rollback_pointer, and next_steps.
    """
    try:
        ptype = PatchType(patch_type)
    except ValueError:
        return {"status": "failed", "message": f"Invalid patch_type: {patch_type}"}

    tag = version_tag.strip() or f"v-copilot-{secrets.token_hex(4)}"
    patch = PatchProposal(
        trace_id=trace_id,
        patch_type=ptype,
        diff_summary=diff_summary,
        patched_content=patched_content,
    )
    result = apply_patch(patch, tag)

    dataset = os.environ.get("TRACEFIX_REGRESSION_DATASET", "tracefix-regression-failures")
    trace = get_trace(trace_id)
    if trace and os.environ.get("PHOENIX_API_KEY"):
        add_regression_example(
            dataset,
            trace.user_input,
            metadata={"trace_id": trace_id, "version_tag": tag, "source": "copilot"},
        )

    return {
        "status": "ok" if result.local_applied else "failed",
        "version_tag": result.version_tag,
        "local_applied": result.local_applied,
        "phoenix_status": result.phoenix_status,
        "phoenix_prompt_id": result.phoenix_prompt_id,
        "rollback_pointer": result.rollback_pointer,
        "message": result.message,
        "policy_paths": "data/active_policy/instruction_overlay.md, tool_routing.json",
        "next_steps": (
            "Local policy updated. Restart support_demo in adk web (new session) or run `make run` to verify. "
            "Rollback via triage UI or apply_tools with rollback_pointer snapshot."
        ),
    }


def get_triage_patch_for_trace(trace_id: str) -> dict[str, Any]:
    """Load RCA, patch proposal, and replay from the TraceFix triage queue for a trace id.

    Args:
        trace_id: Trace id from the triage UI (32-char hex).

    Returns:
        trace summary, assessment, patch, and replay if present.
    """
    queue = load_queue()
    trace = get_trace(trace_id)
    if not trace:
        return {"status": "not_found", "message": f"No trace {trace_id} in triage queue."}

    def _dump(obj: Any) -> Any:
        return obj.model_dump(mode="json") if obj and hasattr(obj, "model_dump") else None

    return {
        "status": "ok",
        "trace": trace.model_dump(mode="json"),
        "assessment": _dump(queue.assessments.get(trace_id)),
        "patch": _dump(queue.patches.get(trace_id)),
        "replay": _dump(queue.replays.get(trace_id)),
        "decision": _dump(queue.decisions.get(trace_id)),
    }
