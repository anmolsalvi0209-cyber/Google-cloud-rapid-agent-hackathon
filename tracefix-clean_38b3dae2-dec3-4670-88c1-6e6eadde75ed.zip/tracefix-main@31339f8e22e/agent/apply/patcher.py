"""Apply approved patches to local runtime policy."""

from __future__ import annotations

import os
from datetime import datetime

from models import ApplyResult
from apply.phoenix_mcp_client import add_regression_example, upsert_prompt_to_phoenix
from apply.policy_store import PolicyStore
from models import PatchProposal, PatchType
from support_demo.prompt import get_active_instruction


def _merge_routing(existing: dict, patch_content: str) -> dict:
    routing = dict(existing)
    rules = list(routing.get("patch_rules", []))
    if patch_content not in rules:
        rules.append(patch_content)
    routing["patch_rules"] = rules
    if "order_lookup" in patch_content and "customer_history" in patch_content:
        required_before = dict(routing.get("required_before", {}))
        required_before["customer_history"] = ["order_lookup"]
        required_before["eligibility_check"] = ["order_lookup", "policy_lookup"]
        required_before["draft_response"] = ["order_lookup", "policy_lookup"]
        routing["required_before"] = required_before
    return routing


def apply_patch(patch: PatchProposal, version_tag: str) -> ApplyResult:
    store = PolicyStore()
    store.ensure_dirs()

    prior = store.snapshot(version_tag=f"prior-{version_tag}")
    store.save_snapshot(prior)

    overlay = store.read_overlay()
    routing = store.read_routing()

    if patch.patch_type == PatchType.PROMPT:
        block = (
            f"\n\n### Patch {version_tag} ({datetime.utcnow().isoformat()}Z)\n"
            f"{patch.diff_summary}\n\n{patch.patched_content}\n"
        )
        overlay = (overlay + block).strip()
    elif patch.patch_type == PatchType.TOOL_ROUTING:
        routing = _merge_routing(routing, patch.patched_content)

    store.write_active(overlay, routing, version_tag, patch.trace_id)

    result = ApplyResult(
        version_tag=version_tag,
        local_applied=True,
        rollback_pointer=prior.version_tag,
        message="Local policy overlay updated.",
    )

    if os.environ.get("PHOENIX_API_KEY") and os.environ.get("TRACEFIX_DEMO_MODE", "0") != "1":
        prompt_name = os.environ.get("TRACEFIX_PROMPT_NAME", "tracefix/support_refund_agent")
        full_prompt = get_active_instruction()
        phoenix = upsert_prompt_to_phoenix(prompt_name, full_prompt, version_tag)
        result.phoenix_status = phoenix.get("status", "skipped")
        result.phoenix_prompt_id = phoenix.get("prompt_id", "")
        if phoenix.get("message"):
            result.message += f" Phoenix: {phoenix['message']}"
    else:
        result.phoenix_status = "skipped"
        result.message += " Phoenix: skipped (no API key)."

    return result


def rollback_to_version(version_tag: str) -> ApplyResult:
    store = PolicyStore()
    snapshot = store.load_snapshot(version_tag)
    if not snapshot:
        return ApplyResult(
            version_tag=version_tag,
            local_applied=False,
            phoenix_status="skipped",
            message=f"Snapshot {version_tag} not found.",
        )
    store.restore_snapshot(snapshot)
    return ApplyResult(
        version_tag=version_tag,
        local_applied=True,
        phoenix_status="skipped",
        message=f"Rolled back to {version_tag}.",
    )
