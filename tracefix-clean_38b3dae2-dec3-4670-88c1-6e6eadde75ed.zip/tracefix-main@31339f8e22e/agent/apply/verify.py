"""Post-promote verification run."""

from __future__ import annotations

import importlib
import os

from evals.runner import evaluate_run
from llm_config import has_llm_credentials
from models import TraceSummary, VerifyResult
from queue_store import load_queue
from replay.runner import _simulate_patched_run
from run_context import RunContext, clear_run_context, set_run_context


async def verify_after_apply(trace: TraceSummary) -> VerifyResult:
    """Re-run support agent with applied policy and evaluate."""
    simulate = (
        os.environ.get("TRACEFIX_DEMO_MODE", "0") == "1"
        or not has_llm_credentials()
    )

    if simulate:
        queue = load_queue()
        patch = queue.patches.get(trace.trace_id)
        ctx = RunContext(
            trace_id=trace.trace_id,
            session_id=trace.session_id,
            user_input=trace.user_input,
            agent_output=trace.agent_output,
            failure_seed_id=trace.failure_seed_id,
        )
        ctx.tool_sequence = list(trace.tool_sequence)
        ctx.token_count = trace.token_count
        ctx.model_calls = max(1, trace.token_count // 500)
        if patch:
            patched = _simulate_patched_run(ctx, patch)
            set_run_context(patched)
            eval_data = evaluate_run(patched)
            clear_run_context()
            return VerifyResult(
                trace_id=patched.trace_id,
                passed=eval_data.get("avg_score", 0) >= 0.75,
                avg_score=eval_data.get("avg_score", 0),
                scores=eval_data.get("scores", {}),
                tool_sequence=patched.tool_sequence,
                message="Simulated verification after apply",
            )

    from run_support import run_turn

    import support_demo.prompt as prompt_mod
    import support_demo.agent as agent_mod

    importlib.reload(prompt_mod)
    importlib.reload(agent_mod)

    try:
        result = await run_turn(
            trace.user_input,
            failure_seed_id=trace.failure_seed_id,
            simulate_only=False,
        )
    except Exception as exc:
        return VerifyResult(
            trace_id=trace.trace_id,
            passed=False,
            avg_score=0.0,
            scores={},
            tool_sequence=[],
            message=f"Verification skipped — agent error: {type(exc).__name__}: {exc}",
        )

    eval_data = result.get("eval", {})
    avg = eval_data.get("avg_score", 0.0)
    passed = avg >= 0.75 and eval_data.get("status") == "passed"

    return VerifyResult(
        trace_id=result.get("trace_id", ""),
        passed=passed,
        avg_score=avg,
        scores=eval_data.get("scores", {}),
        tool_sequence=result.get("tool_sequence", []),
        message="Verification passed" if passed else "Verification below threshold",
    )
