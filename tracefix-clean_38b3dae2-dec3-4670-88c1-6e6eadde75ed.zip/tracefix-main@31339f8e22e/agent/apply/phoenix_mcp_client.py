"""Standalone Phoenix MCP client for promote-time writes."""

from __future__ import annotations

import asyncio
import concurrent.futures
import json
import os
from typing import Any, Coroutine, Optional, TypeVar

T = TypeVar("T")

_thread_pool: concurrent.futures.ThreadPoolExecutor | None = None


def _executor() -> concurrent.futures.ThreadPoolExecutor:
    global _thread_pool
    if _thread_pool is None:
        _thread_pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=2,
            thread_name_prefix="tracefix-phoenix-mcp",
        )
    return _thread_pool


def run_async(coro: Coroutine[Any, Any, T]) -> T:
    """Run async MCP I/O from sync code, including inside ADK's running event loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    return _executor().submit(asyncio.run, coro).result()


def _phoenix_base_url() -> str:
    return (
        os.environ.get("PHOENIX_COLLECTOR_ENDPOINT")
        or os.environ.get("PHOENIX_BASE_URL")
        or "https://app.phoenix.arize.com"
    )


def _mcp_server_params() -> dict[str, Any]:
    command = os.environ.get("TRACEFIX_MCP_COMMAND", "npx")
    args = os.environ.get("TRACEFIX_MCP_ARGS", "").split()
    if not args:
        # Flattened npx installs often omit peers: ajv (for ajv-formats), zod-to-json-schema (for MCP SDK).
        args = [
            "-y",
            "-p",
            "ajv@8",
            "-p",
            "zod-to-json-schema@3",
            "-p",
            "@arizeai/phoenix-mcp@latest",
            "phoenix-mcp",
            "--baseUrl",
            _phoenix_base_url(),
            "--apiKey",
            os.environ.get("PHOENIX_API_KEY", ""),
        ]
    return {
        "command": command,
        "args": args,
        "env": {
            **os.environ,
            "PHOENIX_API_KEY": os.environ.get("PHOENIX_API_KEY", ""),
            "PHOENIX_HOST": _phoenix_base_url(),
        },
    }


async def _call_mcp_tool(tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    try:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client
    except ImportError:
        return {"status": "skipped", "message": "mcp package unavailable"}

    params = _mcp_server_params()
    server_params = StdioServerParameters(
        command=params["command"],
        args=params["args"],
        env=params["env"],
    )

    timeout = float(os.environ.get("TRACEFIX_MCP_TIMEOUT_SEC", "15"))
    try:
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await asyncio.wait_for(session.initialize(), timeout=timeout)
                result = await asyncio.wait_for(
                    session.call_tool(tool_name, arguments=arguments),
                    timeout=timeout,
                )
                content = ""
                if result.content:
                    for block in result.content:
                        if hasattr(block, "text"):
                            content += block.text
                try:
                    return {"status": "ok", "data": json.loads(content) if content else {}}
                except json.JSONDecodeError:
                    return {"status": "ok", "data": {"raw": content}}
    except Exception as exc:
        return {"status": "failed", "message": str(exc)}


def upsert_prompt_to_phoenix(name: str, content: str, version_tag: str) -> dict[str, str]:
    if not os.environ.get("PHOENIX_API_KEY"):
        return {"status": "skipped", "message": "No PHOENIX_API_KEY"}

    result = run_async(
        _call_mcp_tool(
            "upsert-prompt",
            {
                "promptIdentifier": name,
                "prompt": content,
                "description": f"TraceFix auto-apply {version_tag}",
            },
        )
    )
    if result.get("status") != "ok":
        return {
            "status": result.get("status", "failed"),
            "message": result.get("message", "MCP upsert failed"),
        }

    prompt_id = ""
    data = result.get("data", {})
    if isinstance(data, dict):
        prompt_id = str(data.get("id") or data.get("promptId") or name)

    tag_result = run_async(
        _call_mcp_tool(
            "add-prompt-version-tag",
            {"promptIdentifier": name, "tag": version_tag},
        )
    )
    msg = "Prompt upserted"
    if tag_result.get("status") != "ok":
        msg += f"; tag skipped: {tag_result.get('message', '')}"

    return {"status": "ok", "prompt_id": prompt_id, "message": msg}


def add_regression_example(
    dataset_name: str,
    user_input: str,
    metadata: Optional[dict[str, Any]] = None,
) -> dict[str, str]:
    if not os.environ.get("PHOENIX_API_KEY"):
        return {"status": "skipped", "message": "No PHOENIX_API_KEY"}

    result = run_async(
        _call_mcp_tool(
            "add-dataset-examples",
            {
                "datasetName": dataset_name,
                "examples": [
                    {
                        "input": user_input,
                        "metadata": metadata or {},
                    }
                ],
            },
        )
    )
    if result.get("status") != "ok":
        return {
            "status": result.get("status", "failed"),
            "message": result.get("message", "MCP dataset write failed"),
        }
    return {"status": "ok", "message": "Regression example added"}
