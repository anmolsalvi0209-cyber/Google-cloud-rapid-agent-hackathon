"""Models for patch application (policy snapshots)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class PolicySnapshot(BaseModel):
    version_tag: str
    instruction_overlay: str = ""
    tool_routing: dict[str, Any] = Field(default_factory=dict)
    applied_patches: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
