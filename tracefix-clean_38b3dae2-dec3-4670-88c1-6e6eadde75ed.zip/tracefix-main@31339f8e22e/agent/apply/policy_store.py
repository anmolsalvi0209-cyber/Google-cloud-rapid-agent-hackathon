"""Read/write active policy overlays and version history."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional

from apply.models import PolicySnapshot

DEFAULT_ROUTING = {
    "required_before": {
        "customer_history": ["order_lookup"],
        "eligibility_check": ["order_lookup", "policy_lookup"],
        "draft_response": ["order_lookup", "policy_lookup"],
    },
    "required_prefix": ["order_lookup", "policy_lookup"],
}


def _policy_dir() -> Path:
    data_dir = Path(os.environ.get("TRACEFIX_DATA_DIR", "./data"))
    if not data_dir.is_absolute():
        agent_dir = Path(__file__).resolve().parents[1]
        project_root = agent_dir.parent
        data_dir = project_root / data_dir
    return data_dir / "active_policy"


class PolicyStore:
    def __init__(self, root: Optional[Path] = None) -> None:
        self.root = root or _policy_dir()
        self.overlay_path = self.root / "instruction_overlay.md"
        self.routing_path = self.root / "tool_routing.json"
        self.manifest_path = self.root / "manifest.json"
        self.history_dir = self.root / "history"

    def ensure_dirs(self) -> None:
        self.history_dir.mkdir(parents=True, exist_ok=True)

    def read_overlay(self) -> str:
        if self.overlay_path.exists():
            return self.overlay_path.read_text().strip()
        return ""

    def read_routing(self) -> dict[str, Any]:
        if self.routing_path.exists():
            return json.loads(self.routing_path.read_text())
        return dict(DEFAULT_ROUTING)

    def read_manifest(self) -> dict[str, Any]:
        if self.manifest_path.exists():
            return json.loads(self.manifest_path.read_text())
        return {"current_version": "", "applied_patches": []}

    def snapshot(self, version_tag: str) -> PolicySnapshot:
        manifest = self.read_manifest()
        return PolicySnapshot(
            version_tag=version_tag,
            instruction_overlay=self.read_overlay(),
            tool_routing=self.read_routing(),
            applied_patches=list(manifest.get("applied_patches", [])),
        )

    def save_snapshot(self, snapshot: PolicySnapshot) -> Path:
        self.ensure_dirs()
        path = self.history_dir / f"{snapshot.version_tag}.json"
        path.write_text(snapshot.model_dump_json(indent=2))
        return path

    def load_snapshot(self, version_tag: str) -> Optional[PolicySnapshot]:
        path = self.history_dir / f"{version_tag}.json"
        if not path.exists():
            return None
        return PolicySnapshot.model_validate_json(path.read_text())

    def write_active(
        self,
        overlay: str,
        routing: dict[str, Any],
        version_tag: str,
        patch_id: str,
    ) -> None:
        self.ensure_dirs()
        self.overlay_path.write_text(overlay)
        self.routing_path.write_text(json.dumps(routing, indent=2))
        manifest = self.read_manifest()
        applied = list(manifest.get("applied_patches", []))
        if patch_id not in applied:
            applied.append(patch_id)
        self.manifest_path.write_text(
            json.dumps(
                {"current_version": version_tag, "applied_patches": applied},
                indent=2,
            )
        )

    def restore_snapshot(self, snapshot: PolicySnapshot) -> None:
        self.write_active(
            snapshot.instruction_overlay,
            snapshot.tool_routing,
            snapshot.version_tag,
            f"rollback-{snapshot.version_tag}",
        )
