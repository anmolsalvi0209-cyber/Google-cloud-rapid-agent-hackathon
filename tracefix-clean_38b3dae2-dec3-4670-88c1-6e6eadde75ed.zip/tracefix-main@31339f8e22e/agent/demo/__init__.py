"""Demo fixtures and seeded failure scripts."""
