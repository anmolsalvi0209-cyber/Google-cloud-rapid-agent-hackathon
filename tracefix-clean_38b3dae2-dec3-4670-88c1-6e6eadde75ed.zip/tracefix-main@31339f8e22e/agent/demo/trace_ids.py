"""Deterministic demo trace ids (32-char OpenTelemetry shape)."""

from __future__ import annotations

import hashlib

DEMO_SEED_IDS = ("hallucinated_policy", "wrong_tool_order", "cost_overrun")


def seed_trace_id(seed_id: str) -> str:
    """Stable 32-char hex id per demo scenario (survives re-seed)."""
    return hashlib.sha256(f"tracefix.demo.{seed_id}".encode()).hexdigest()[:32]


def resolve_trace_ref(ref: str) -> str:
    """Map scenario name or legacy `seed-*` label to the queue trace id."""
    if ref in DEMO_SEED_IDS:
        return seed_trace_id(ref)
    if ref.startswith("seed-"):
        seed_id = ref.removeprefix("seed-")
        if seed_id in DEMO_SEED_IDS:
            return seed_trace_id(seed_id)
    return ref


SEED_TRACE_IDS: dict[str, str] = {seed_id: seed_trace_id(seed_id) for seed_id in DEMO_SEED_IDS}
