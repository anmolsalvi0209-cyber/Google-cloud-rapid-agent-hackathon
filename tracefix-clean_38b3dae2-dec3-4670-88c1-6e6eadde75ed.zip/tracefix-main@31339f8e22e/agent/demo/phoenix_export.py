"""Export simulated demo seeds to Phoenix with deterministic trace ids."""

from __future__ import annotations

import os
import secrets

from opentelemetry import trace
from opentelemetry.trace import NonRecordingSpan, SpanContext, TraceFlags, set_span_in_context

from instrumentation import _phoenix_configured, setup_tracing
from run_context import RunContext


def export_seed_trace_to_phoenix(ctx: RunContext, failure_labels: list[str]) -> bool:
    """Emit OTLP spans so MCP get-trace finds the same id as the triage queue."""
    if not _phoenix_configured():
        return False

    setup_tracing()
    trace_id_int = int(ctx.trace_id, 16)
    root_span_id = int(secrets.token_hex(8), 16)
    parent = SpanContext(
        trace_id=trace_id_int,
        span_id=root_span_id,
        is_remote=False,
        trace_flags=TraceFlags(0x01),
    )
    otel_ctx = set_span_in_context(NonRecordingSpan(parent))
    tracer = trace.get_tracer("tracefix.demo")

    attrs: dict[str, str | int | float | bool] = {
        "tracefix.demo": True,
        "input.value": ctx.user_input[:2000],
        "output.value": ctx.agent_output[:2000],
        "openinference.span.kind": "CHAIN",
    }
    if ctx.failure_seed_id:
        attrs["tracefix.failure_seed_id"] = ctx.failure_seed_id
    if failure_labels:
        attrs["tracefix.failure_labels"] = ",".join(failure_labels)

    with tracer.start_as_current_span("support_turn", context=otel_ctx, attributes=attrs):
        for tool_name in ctx.tool_sequence:
            with tracer.start_as_current_span(
                tool_name,
                attributes={
                    "openinference.span.kind": "TOOL",
                    "tool.name": tool_name,
                },
            ):
                pass

    provider = trace.get_tracer_provider()
    if hasattr(provider, "force_flush"):
        provider.force_flush(timeout_millis=5000)
    return True
