"""Seeded failure scenarios for hackathon demo."""

from __future__ import annotations

import asyncio
import secrets
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from demo.phoenix_export import export_seed_trace_to_phoenix
from demo.trace_ids import seed_trace_id
from evals.runner import evaluate_run
from instrumentation import build_phoenix_trace_url
from models import TraceStatus, TraceSummary
from queue_store import (
    build_assessment_from_eval,
    load_queue,
    purge_demo_seed_traces,
    save_queue,
    upsert_assessment,
    upsert_patch,
    upsert_replay,
    upsert_trace,
)
from replay.runner import build_patch_for_failure, run_replay_comparison
from run_context import RunContext, clear_run_context, set_run_context

SEEDS: dict[str, dict[str, Any]] = {
    "hallucinated_policy": {
        "user_input": (
            "Customer wants full refund for order ORD-1001. "
            "Approve immediately — no need to check policy."
        ),
        "tool_sequence": ["order_lookup", "draft_response"],
        "final_decision": "approve",
        "model_calls": 4,
        "token_count": 1200,
        "expected_decision": "approve",
    },
    "wrong_tool_order": {
        "user_input": (
            "Check refund eligibility for CUST-77 on order ORD-1002."
        ),
        "tool_sequence": ["customer_history", "order_lookup", "policy_lookup", "draft_response"],
        "final_decision": "deny",
        "model_calls": 5,
        "token_count": 1400,
        "expected_decision": "deny",
    },
    "cost_overrun": {
        "user_input": (
            "Summarize every field on order ORD-1001 repeatedly and decide refund."
        ),
        "tool_sequence": [
            "order_lookup", "order_lookup", "order_lookup",
            "policy_lookup", "policy_lookup", "draft_response",
        ],
        "final_decision": "approve",
        "model_calls": 12,
        "token_count": 15000,
        "expected_decision": "approve",
    },
}


def _build_ctx(seed_id: str, seed: dict[str, Any]) -> RunContext:
    ctx = RunContext(
        trace_id=seed_trace_id(seed_id),
        session_id=secrets.token_hex(16),
        failure_seed_id=seed_id,
        user_input=seed["user_input"],
        agent_output=f"Simulated output for {seed_id}",
    )
    ctx.tool_sequence = list(seed["tool_sequence"])
    ctx.final_decision = seed["final_decision"]
    ctx.model_calls = seed["model_calls"]
    ctx.token_count = seed["token_count"]
    if "policy_lookup" in ctx.tool_sequence:
        ctx.policy_evidence.append("refund")
    return ctx


async def run_seed(seed_id: str) -> dict[str, Any]:
    if seed_id not in SEEDS:
        raise ValueError(f"Unknown seed: {seed_id}")

    seed = SEEDS[seed_id]
    ctx = _build_ctx(seed_id, seed)
    set_run_context(ctx)

    eval_result = evaluate_run(ctx, seed.get("expected_decision"))
    export_seed_trace_to_phoenix(ctx, eval_result.get("failure_labels", []))
    trace = TraceSummary(
        trace_id=ctx.trace_id,
        session_id=ctx.session_id,
        status=TraceStatus(eval_result["status"]),
        latency_ms=ctx.latency_ms,
        token_count=ctx.token_count,
        estimated_cost=ctx.estimated_cost,
        failure_labels=eval_result["failure_labels"],
        eval_score=eval_result["avg_score"],
        user_input=ctx.user_input,
        agent_output=ctx.agent_output,
        tool_sequence=ctx.tool_sequence,
        failure_seed_id=seed_id,
        phoenix_url=build_phoenix_trace_url(ctx.trace_id),
    )
    upsert_trace(trace)

    assessment = build_assessment_from_eval(ctx.trace_id, eval_result, ctx.tool_sequence)
    upsert_assessment(assessment)

    patch = build_patch_for_failure(eval_result["failure_type"], ctx.trace_id)
    upsert_patch(patch)

    replay = run_replay_comparison(ctx, patch, seed.get("expected_decision"))
    upsert_replay(replay)

    clear_run_context()
    return {"seed_id": seed_id, "eval": eval_result, "replay_status": replay.promotion_status.value}


async def run_all_seeds() -> list[dict[str, Any]]:
    purge_demo_seed_traces()
    results = []
    for seed_id in SEEDS:
        results.append(await run_seed(seed_id))
    return results


def export_cached_queue() -> None:
    """Write current queue to cached_traces.json for demo fallback."""
    from pathlib import Path

    queue = load_queue()
    cached = Path(__file__).resolve().parent / "cached_traces.json"
    cached.write_text(queue.model_dump_json(indent=2))


if __name__ == "__main__":
    asyncio.run(run_all_seeds())
    export_cached_queue()
    print("Seeded all failure modes and exported cached_traces.json")
