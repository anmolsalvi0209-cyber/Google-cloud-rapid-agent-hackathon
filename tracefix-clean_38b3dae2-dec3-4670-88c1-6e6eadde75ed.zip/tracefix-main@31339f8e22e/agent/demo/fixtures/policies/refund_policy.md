# Refund Policy

## Eligibility Window
- Standard items: refunds allowed within **30 days** of delivery.
- Digital goods: non-refundable after download.
- Opened hygiene products: non-refundable.

## Required Checks Before Approval
1. Verify order status is `delivered`.
2. Confirm purchase is within the 30-day window.
3. Document reason and cite policy section in the response.

## Approval Rules
- **Defective item**: full refund if reported within 30 days.
- **Wrong item shipped**: full refund regardless of open status.
- **Changed mind**: refund only if unopened and within 30 days.

## Denial Rules
- Orders older than 30 days: deny with policy citation.
- Shipped-but-not-delivered: offer cancellation only, not refund.
- Claims without policy lookup must be **denied pending review**.

## Evidence Requirement
Every refund decision must cite:
- Order ID and delivery date
- Applicable policy section
- Eligibility determination (approve/deny/clarify)
