"""CLI entrypoint — delegates to run_support."""

from run_support import main

if __name__ == "__main__":
    main()
