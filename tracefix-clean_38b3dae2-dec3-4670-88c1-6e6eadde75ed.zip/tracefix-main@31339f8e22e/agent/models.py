"""TraceFix domain models for triage, RCA, replay, and promotion."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class FailureType(str, Enum):
    HALLUCINATION = "hallucination"
    WRONG_TOOL_ROUTE = "wrong_tool_route"
    BAD_TOOL_ARGUMENTS = "bad_tool_arguments"
    COST_SPIKE = "cost_spike"
    AMBIGUOUS_PROMPT = "ambiguous_prompt"
    TIMEOUT = "timeout"
    UNKNOWN = "unknown"


class TraceStatus(str, Enum):
    PASSED = "passed"
    FAILED = "failed"
    SUSPICIOUS = "suspicious"


class PromotionStatus(str, Enum):
    PENDING = "pending"
    READY = "ready"
    REJECTED = "rejected"
    PROMOTED = "promoted"


class TraceSummary(BaseModel):
    trace_id: str
    session_id: str = ""
    status: TraceStatus = TraceStatus.SUSPICIOUS
    start_time: datetime = Field(default_factory=datetime.utcnow)
    latency_ms: float = 0.0
    token_count: int = 0
    estimated_cost: float = 0.0
    failure_labels: list[str] = Field(default_factory=list)
    eval_score: float = 0.0
    user_input: str = ""
    agent_output: str = ""
    tool_sequence: list[str] = Field(default_factory=list)
    failure_seed_id: Optional[str] = None
    phoenix_url: Optional[str] = None


class FailureAssessment(BaseModel):
    trace_id: str
    failure_type: FailureType = FailureType.UNKNOWN
    confidence: float = 0.0
    evidence_spans: list[str] = Field(default_factory=list)
    evaluator_scores: dict[str, float] = Field(default_factory=dict)
    natural_language_rca: str = ""


class PatchType(str, Enum):
    PROMPT = "prompt"
    TOOL_ROUTING = "tool_routing"
    EVALUATOR = "evaluator"
    RETRY_RULE = "retry_rule"
    DATASET = "dataset"


class PatchProposal(BaseModel):
    trace_id: str
    patch_type: PatchType = PatchType.PROMPT
    target_prompt_or_tool: str = ""
    diff_summary: str = ""
    patched_content: str = ""
    risk_level: str = "medium"
    expected_metric_change: dict[str, str] = Field(default_factory=dict)


class ReplayResult(BaseModel):
    baseline_trace_id: str
    patched_run_id: str = ""
    dataset_id: str = ""
    experiment_id: str = ""
    baseline_scores: dict[str, float] = Field(default_factory=dict)
    patched_scores: dict[str, float] = Field(default_factory=dict)
    score_delta: dict[str, float] = Field(default_factory=dict)
    cost_delta: float = 0.0
    latency_delta_ms: float = 0.0
    promotion_status: PromotionStatus = PromotionStatus.PENDING


class ApplyResult(BaseModel):
    version_tag: str
    local_applied: bool = False
    phoenix_prompt_id: str = ""
    phoenix_status: str = "skipped"
    message: str = ""
    rollback_pointer: str = ""


class VerifyResult(BaseModel):
    trace_id: str = ""
    passed: bool = False
    avg_score: float = 0.0
    scores: dict[str, float] = Field(default_factory=dict)
    tool_sequence: list[str] = Field(default_factory=list)
    message: str = ""


class DecisionLog(BaseModel):
    trace_id: str
    human_approved: bool = False
    rejected_reason: str = ""
    promoted_version_tag: str = ""
    rollback_pointer: str = ""
    apply_result: Optional[ApplyResult] = None
    verify_trace_id: str = ""
    verify_passed: bool = False
    verify_result: Optional[VerifyResult] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class TriageQueue(BaseModel):
    mode: str = "live"
    traces: list[TraceSummary] = Field(default_factory=list)
    assessments: dict[str, FailureAssessment] = Field(default_factory=dict)
    patches: dict[str, PatchProposal] = Field(default_factory=dict)
    replays: dict[str, ReplayResult] = Field(default_factory=dict)
    decisions: dict[str, DecisionLog] = Field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json")
