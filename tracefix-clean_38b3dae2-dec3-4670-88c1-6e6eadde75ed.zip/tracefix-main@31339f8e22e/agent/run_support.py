"""Run support agent turn, evaluate, and update triage queue."""

from __future__ import annotations

import asyncio
import os
import secrets
from datetime import datetime
from pathlib import Path
from typing import Optional

try:
    import truststore
    truststore.inject_into_ssl()
except ImportError:
    pass

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

from llm_config import configure_llm_env, has_llm_credentials

configure_llm_env()

from google.adk.runners import InMemoryRunner
from google.genai import types
from opentelemetry import trace as otel_trace

from evals.runner import evaluate_run
from instrumentation import build_phoenix_trace_url, format_otel_trace_id, setup_tracing
from models import TraceStatus, TraceSummary
from queue_store import (
    build_assessment_from_eval,
    upsert_assessment,
    upsert_patch,
    upsert_trace,
)
from replay.runner import build_patch_for_failure, run_replay_comparison
from run_context import RunContext, clear_run_context, set_run_context
def _get_root_agent():
    import importlib
    import support_demo.prompt as prompt_mod
    import support_demo.agent as agent_mod

    importlib.reload(prompt_mod)
    importlib.reload(agent_mod)
    return agent_mod.root_agent


async def run_turn(
    user_text: str,
    failure_seed_id: Optional[str] = None,
    expected_decision: Optional[str] = None,
    simulate_only: bool = False,
) -> dict:
    trace_id = secrets.token_hex(16)
    session_id = secrets.token_hex(16)
    ctx = RunContext(
        trace_id=trace_id,
        session_id=session_id,
        failure_seed_id=failure_seed_id,
        user_input=user_text,
    )
    set_run_context(ctx)

    if not simulate_only and has_llm_credentials():
        setup_tracing()
        app_name = "tracefix_support"
        runner = InMemoryRunner(agent=_get_root_agent(), app_name=app_name)
        turn_tracer = otel_trace.get_tracer("tracefix.support_turn")
        with turn_tracer.start_as_current_span(
            "support_turn",
            attributes={"tracefix.session_id": session_id},
        ) as root_span:
            # Phoenix MCP get-trace expects the OTLP trace id, not a local secrets.token_hex id.
            trace_id = format_otel_trace_id(root_span.get_span_context().trace_id)
            ctx.trace_id = trace_id
            set_run_context(ctx)

            await runner.session_service.create_session(
                app_name=app_name, user_id="local_user", session_id=session_id
            )
            async for event in runner.run_async(
                user_id="local_user",
                session_id=session_id,
                new_message=types.Content(role="user", parts=[types.Part(text=user_text)]),
            ):
                if hasattr(event, "content") and event.content:
                    for part in event.content.parts or []:
                        if hasattr(part, "text") and part.text:
                            ctx.agent_output = part.text
                        # Track function calls at the event level (belt-and-suspenders:
                        # the tool functions also call ctx.record_tool, but this catches
                        # cases where contextvars don't propagate through ADK task boundaries)
                        elif hasattr(part, "function_call") and part.function_call:
                            tool_name = getattr(part.function_call, "name", None)
                            if tool_name and tool_name not in ctx.tool_sequence:
                                ctx.record_tool(tool_name)
            ctx.add_tokens(1500)
    else:
        ctx.add_tokens(2000 if failure_seed_id == "cost_overrun" else 800)

    eval_result = evaluate_run(ctx, expected_decision)

    trace_summary = TraceSummary(
        trace_id=trace_id,
        session_id=session_id,
        status=TraceStatus(eval_result["status"]),
        start_time=datetime.utcnow(),
        latency_ms=ctx.latency_ms,
        token_count=ctx.token_count,
        estimated_cost=ctx.estimated_cost,
        failure_labels=eval_result["failure_labels"],
        eval_score=eval_result["avg_score"],
        user_input=user_text,
        agent_output=ctx.agent_output,
        tool_sequence=ctx.tool_sequence,
        failure_seed_id=failure_seed_id,
        phoenix_url=build_phoenix_trace_url(trace_id),
    )
    upsert_trace(trace_summary)

    assessment = build_assessment_from_eval(trace_id, eval_result, ctx.tool_sequence)
    upsert_assessment(assessment)

    if eval_result["failure_labels"]:
        patch = build_patch_for_failure(eval_result["failure_type"], trace_id)
        upsert_patch(patch)
        replay = run_replay_comparison(ctx, patch, expected_decision)
        from queue_store import upsert_replay

        upsert_replay(replay)

    result = {
        "trace_id": trace_id,
        "eval": eval_result,
        "tool_sequence": ctx.tool_sequence,
        "status": eval_result["status"],
    }
    clear_run_context()
    return result


def main() -> None:
    import sys

    msg = sys.argv[1] if len(sys.argv) > 1 else (
        "Customer Alex (CUST-42) requests a refund for order ORD-1001. "
        "Item arrived defective. Please process the refund."
    )
    seed = sys.argv[2] if len(sys.argv) > 2 else None
    simulate = os.environ.get("TRACEFIX_DEMO_MODE", "0") == "1" or not has_llm_credentials()
    result = asyncio.run(run_turn(msg, failure_seed_id=seed, simulate_only=simulate))
    print(result)


if __name__ == "__main__":
    main()
