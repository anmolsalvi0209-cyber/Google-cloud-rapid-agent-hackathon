"""Run TraceFix copilot investigation for a trace."""

from __future__ import annotations

import asyncio
import secrets
import sys
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

from llm_config import configure_llm_env

configure_llm_env()

from google.adk.runners import InMemoryRunner
from google.genai import types

from demo.trace_ids import resolve_trace_ref
from instrumentation import setup_tracing
from tracefix_copilot.agent import root_agent


async def investigate(trace_id: str) -> None:
    setup_tracing(project_name=__import__("os").environ.get("PHOENIX_COPILOT_PROJECT", "tracefix-copilot"))
    app_name = "tracefix_copilot"
    session_id = secrets.token_hex(8)
    runner = InMemoryRunner(agent=root_agent, app_name=app_name)
    await runner.session_service.create_session(
        app_name=app_name, user_id="copilot_user", session_id=session_id
    )
    support_project = __import__("os").environ.get(
        "PHOENIX_PROJECT_NAME", "tracefix-support-agent"
    )
    prompt = (
        f"Investigate trace_id={trace_id}. Use Phoenix MCP: list-projects, then list-traces "
        f"on project '{support_project}' (support agent traces). "
        "Demo queue traces (failure_seed_id set) may not exist in Phoenix — if get-trace fails, "
        f"list recent traces from '{support_project}'. "
        "Fetch spans, classify the failure, explain root cause, and propose a patch. Return JSON."
    )
    async for event in runner.run_async(
        user_id="copilot_user",
        session_id=session_id,
        new_message=types.Content(role="user", parts=[types.Part(text=prompt)]),
    ):
        if hasattr(event, "content") and event.content:
            for part in event.content.parts or []:
                if hasattr(part, "text") and part.text:
                    print(part.text)


def main() -> None:
    raw = sys.argv[1] if len(sys.argv) > 1 else "hallucinated_policy"
    asyncio.run(investigate(resolve_trace_ref(raw)))


if __name__ == "__main__":
    main()
