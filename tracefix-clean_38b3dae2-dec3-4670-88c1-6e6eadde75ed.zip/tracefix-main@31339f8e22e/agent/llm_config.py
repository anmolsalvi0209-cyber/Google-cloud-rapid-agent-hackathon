"""Configure Gemini auth: direct Google API key or Vertex AI."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Union

if TYPE_CHECKING:
    from google.adk.models.google_llm import Gemini as GeminiLlm


def configure_llm_env() -> None:
    """Ensure google-genai / ADK env vars are set from .env."""
    if os.environ.get("GOOGLE_GENAI_USE_VERTEXAI", "0") not in ("1", "true", "True"):
        os.environ.setdefault("GOOGLE_GENAI_USE_VERTEXAI", "0")


def has_llm_credentials() -> bool:
    """True when there are enough credentials to call Gemini."""
    if os.environ.get("GOOGLE_GENAI_USE_VERTEXAI", "0") in ("1", "true", "True"):
        return bool((os.environ.get("GOOGLE_CLOUD_PROJECT") or "").strip())
    return bool((os.environ.get("GOOGLE_API_KEY") or "").strip())


def get_gemini_model(default: str = "gemini-2.5-flash") -> str:
    """Return the model ID from env or default."""
    return (os.environ.get("GEMINI_MODEL") or "").strip() or default


def get_adk_agent_model() -> Union[str, "GeminiLlm"]:
    """Model value for ``google.adk.agents.Agent(model=...)``."""
    from google.adk.models.registry import LLMRegistry

    raw = get_gemini_model()
    try:
        LLMRegistry.resolve(raw)
    except ValueError:
        from google.adk.models.google_llm import Gemini
        return Gemini(model=raw)
    return raw


def llm_config_summary() -> dict[str, str]:
    """Non-secret summary for /api/config."""
    return {
        "gemini_auth_mode": "google",
        "gemini_model": get_gemini_model(),
        "gemini_base_url": (
            os.environ.get("GOOGLE_GEMINI_BASE_URL")
            or "https://generativelanguage.googleapis.com"
        ),
        "gemini_use_vertex": os.environ.get("GOOGLE_GENAI_USE_VERTEXAI", "0"),
    }
