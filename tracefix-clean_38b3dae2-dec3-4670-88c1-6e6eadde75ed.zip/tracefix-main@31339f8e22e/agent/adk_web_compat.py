"""Compatibility shims for ADK Web UI ↔ server route mismatches."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("tracefix.adk_web_compat")


def install_adk_web_compat() -> None:
    """Register missing routes expected by the bundled ADK Web frontend."""
    from google.adk.cli import fast_api as adk_fast_api

    if getattr(adk_fast_api.get_fast_api_app, "_tracefix_patched", False):
        return

    _original = adk_fast_api.get_fast_api_app

    def get_fast_api_app_with_compat(*args: Any, **kwargs: Any):
        app = _original(*args, **kwargs)
        _register_build_graph_image_route(app, kwargs.get("agents_dir", "agent"))
        return app

    get_fast_api_app_with_compat._tracefix_patched = True  # type: ignore[attr-defined]
    adk_fast_api.get_fast_api_app = get_fast_api_app_with_compat


def _register_build_graph_image_route(app: Any, agents_dir: str) -> None:
    """ADK Web JS calls GET /dev/build_graph_image/{app} expecting {dotSrc: ...}."""
    import graphviz
    from fastapi import HTTPException
    from google.adk.agents.base_agent import BaseAgent
    from google.adk.apps.app import App  # noqa: PLC0415
    from google.adk.cli import agent_graph
    from google.adk.cli.utils.agent_loader import AgentLoader

    loader = AgentLoader(agents_dir)

    def _root_agent(agent_or_app: BaseAgent | App) -> BaseAgent:
        if isinstance(agent_or_app, App):
            return agent_or_app.root_agent
        return agent_or_app

    @app.get("/dev/build_graph_image/{app_name}")
    async def build_graph_image_compat(
        app_name: str,
        dark_mode: bool = False,
        node: str | None = None,
    ) -> dict[str, str]:
        del node  # frontend may pass highlight node; base graph ignores it
        try:
            agent_or_app = loader.load_agent(app_name)
            root = _root_agent(agent_or_app)
            dot_graph = await agent_graph.get_agent_graph(root, [], dark_mode=dark_mode)
            if dot_graph and isinstance(dot_graph, graphviz.Digraph):
                return {"dotSrc": dot_graph.source}
            raise HTTPException(404, f"Graph not available for app: {app_name}")
        except HTTPException:
            raise
        except Exception as exc:
            logger.warning("build_graph_image failed for %s: %s", app_name, exc)
            raise HTTPException(404, f"Graph not available for app: {app_name}") from exc
