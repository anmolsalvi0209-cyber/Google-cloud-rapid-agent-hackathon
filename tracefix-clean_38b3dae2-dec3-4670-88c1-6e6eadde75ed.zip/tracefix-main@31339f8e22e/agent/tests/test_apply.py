"""Unit tests for patch application."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pytest

os.environ.setdefault("TRACEFIX_DATA_DIR", tempfile.mkdtemp())

from apply.patcher import apply_patch, rollback_to_version
from apply.policy_store import PolicyStore
from models import PatchProposal, PatchType


def test_apply_prompt_patch():
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["TRACEFIX_DATA_DIR"] = tmp
        patch = PatchProposal(
            trace_id="test-trace",
            patch_type=PatchType.PROMPT,
            patched_content="ALWAYS call policy_lookup first.",
            diff_summary="Require policy lookup",
        )
        result = apply_patch(patch, "v-test01")
        assert result.local_applied is True

        store = PolicyStore()
        overlay = store.read_overlay()
        assert "policy_lookup" in overlay
        assert result.rollback_pointer.startswith("prior-")


def test_apply_tool_routing_patch():
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["TRACEFIX_DATA_DIR"] = tmp
        patch = PatchProposal(
            trace_id="test-trace",
            patch_type=PatchType.TOOL_ROUTING,
            patched_content="order_lookup before customer_history",
            diff_summary="Fix tool order",
        )
        apply_patch(patch, "v-test02")
        store = PolicyStore()
        routing = store.read_routing()
        assert "customer_history" in routing.get("required_before", {})


def test_rollback():
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["TRACEFIX_DATA_DIR"] = tmp
        store = PolicyStore()
        snap = store.snapshot("v-before")
        store.save_snapshot(snap)
        store.write_active("overlay", {"required_before": {}}, "v-after", "p1")
        result = rollback_to_version("v-before")
        assert result.local_applied is True
        assert store.read_overlay() == ""
