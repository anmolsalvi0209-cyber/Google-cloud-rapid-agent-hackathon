"""Tests for Gemini auth configuration."""

from __future__ import annotations

import os

import pytest

from llm_config import (
    configure_llm_env,
    get_adk_agent_model,
    get_gemini_model,
    has_llm_credentials,
)


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    for key in (
        "GEMINI_AUTH_MODE",
        "GOOGLE_API_KEY",
        "GOOGLE_GEMINI_BASE_URL",
        "GOOGLE_GENAI_USE_VERTEXAI",
        "GEMINI_MODEL",
    ):
        monkeypatch.delenv(key, raising=False)


def test_google_mode_uses_api_key(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "test-google-key")
    monkeypatch.setenv("GOOGLE_GENAI_USE_VERTEXAI", "0")
    configure_llm_env()
    assert has_llm_credentials() is True


def test_no_credentials_returns_false(monkeypatch):
    monkeypatch.setenv("GOOGLE_GENAI_USE_VERTEXAI", "0")
    assert has_llm_credentials() is False


def test_vertex_mode_uses_project(monkeypatch):
    monkeypatch.setenv("GOOGLE_GENAI_USE_VERTEXAI", "1")
    monkeypatch.setenv("GOOGLE_CLOUD_PROJECT", "my-project")
    assert has_llm_credentials() is True


def test_get_gemini_model_from_env(monkeypatch):
    monkeypatch.setenv("GEMINI_MODEL", "gemini-2.5-flash")
    assert get_gemini_model() == "gemini-2.5-flash"


def test_get_gemini_model_default(monkeypatch):
    assert get_gemini_model(default="gemini-2.0-flash") == "gemini-2.0-flash"


def test_get_adk_agent_model_returns_string_for_known_model(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "k")
    monkeypatch.setenv("GEMINI_MODEL", "gemini-2.5-flash")
    configure_llm_env()
    m = get_adk_agent_model()
    assert m == "gemini-2.5-flash"
