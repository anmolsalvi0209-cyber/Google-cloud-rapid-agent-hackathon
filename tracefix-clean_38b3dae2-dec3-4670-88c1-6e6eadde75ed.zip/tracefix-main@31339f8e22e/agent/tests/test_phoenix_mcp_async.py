"""Tests for Phoenix MCP sync/async bridge."""

from __future__ import annotations

import asyncio

from apply.phoenix_mcp_client import run_async


async def _sample_coro() -> str:
    return "ok"


def test_run_async_without_running_loop() -> None:
    assert run_async(_sample_coro()) == "ok"


def test_run_async_inside_running_loop() -> None:
    async def _inner() -> None:
        assert run_async(_sample_coro()) == "ok"

    asyncio.run(_inner())
