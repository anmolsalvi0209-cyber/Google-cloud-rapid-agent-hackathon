"""Start ADK web with TraceFix compatibility patches (graph route, env loading)."""

from __future__ import annotations

import sys
from pathlib import Path

from dotenv import load_dotenv

_REPO_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(_REPO_ROOT / ".env")

from adk_web_compat import install_adk_web_compat

install_adk_web_compat()

from google.adk.cli.cli_tools_click import main  # noqa: E402

if __name__ == "__main__":
    agent_dir = str(Path(__file__).resolve().parent)
    if len(sys.argv) <= 1 or sys.argv[1] != "web":
        sys.argv = [sys.argv[0], "web", agent_dir, *sys.argv[1:]]
    elif len(sys.argv) == 2:
        sys.argv.append(agent_dir)
    main()
