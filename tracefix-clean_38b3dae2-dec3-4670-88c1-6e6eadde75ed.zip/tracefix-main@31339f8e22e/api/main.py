"""TraceFix FastAPI server — triage queue, copilot, replay, promotion."""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

try:
    import truststore
    truststore.inject_into_ssl()
except ImportError:
    pass

AGENT_DIR = Path(__file__).resolve().parent.parent / "agent"
sys.path.insert(0, str(AGENT_DIR))

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

from llm_config import configure_llm_env, llm_config_summary

try:
    configure_llm_env()
except ValueError as exc:
    import logging

    logging.getLogger("tracefix").warning("LLM config: %s", exc)

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from apply.patcher import apply_patch, rollback_to_version
from apply.phoenix_mcp_client import add_regression_example
from apply.verify import verify_after_apply
from models import DecisionLog, PromotionStatus
from queue_store import get_trace, load_queue, upsert_decision, upsert_replay
from replay.promotion import evaluate_promotion
from replay.runner import build_patch_for_failure, run_replay_comparison
from run_context import RunContext

WEB_DIR = Path(__file__).resolve().parent.parent / "web"

app = FastAPI(title="TraceFix", version="0.1.0")


class PromoteRequest(BaseModel):
    approved: bool = True
    rejected_reason: str = ""
    version_tag: str = ""


class RollbackRequest(BaseModel):
    version_tag: str = ""


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "service": "tracefix"}


def _phoenix_configured() -> bool:
    return bool(
        (os.environ.get("PHOENIX_API_KEY") or "").strip()
        or (os.environ.get("PHOENIX_COLLECTOR_ENDPOINT") or "").strip()
    )


@app.get("/api/queue")
def get_queue() -> dict:
    queue = load_queue()
    demo_mode = (
        os.environ.get("TRACEFIX_DEMO_MODE", "0") == "1"
        or not _phoenix_configured()
    )
    queue.mode = "demo" if demo_mode else "live"
    return queue.to_dict()


@app.get("/api/traces/{trace_id}")
def get_trace_detail(trace_id: str) -> dict:
    queue = load_queue()
    trace = get_trace(trace_id)
    if not trace:
        raise HTTPException(404, "Trace not found")

    def _dump(obj):
        if hasattr(obj, "model_dump"):
            return obj.model_dump(mode="json")
        return obj or {}

    return {
        "trace": trace.model_dump(mode="json"),
        "assessment": _dump(queue.assessments.get(trace_id)),
        "patch": _dump(queue.patches.get(trace_id)),
        "replay": _dump(queue.replays.get(trace_id)),
        "decision": _dump(queue.decisions.get(trace_id)),
    }


@app.post("/api/traces/{trace_id}/replay")
def trigger_replay(trace_id: str) -> dict:
    queue = load_queue()
    trace = get_trace(trace_id)
    if not trace:
        raise HTTPException(404, "Trace not found")

    patch = queue.patches.get(trace_id)
    if not patch:
        assessment = queue.assessments.get(trace_id)
        ft = assessment.failure_type.value if hasattr(assessment, "failure_type") else "hallucination"
        patch = build_patch_for_failure(ft, trace_id)

    ctx = RunContext(
        trace_id=trace_id,
        session_id=trace.session_id,
        user_input=trace.user_input,
        agent_output=trace.agent_output,
        failure_seed_id=trace.failure_seed_id,
    )
    ctx.tool_sequence = list(trace.tool_sequence)
    ctx.token_count = trace.token_count
    ctx.model_calls = max(1, trace.token_count // 500)

    replay = run_replay_comparison(ctx, patch)
    upsert_replay(replay)
    return replay.model_dump(mode="json")


@app.post("/api/traces/{trace_id}/promote")
def promote_patch(trace_id: str, body: PromoteRequest) -> dict:
    queue = load_queue()
    replay = queue.replays.get(trace_id)
    if not replay:
        raise HTTPException(404, "No replay result for trace")

    if not body.approved:
        decision = DecisionLog(
            trace_id=trace_id,
            human_approved=False,
            rejected_reason=body.rejected_reason or "Rejected by reviewer",
        )
        upsert_decision(decision)
        return {"decision": decision.model_dump(mode="json")}

    if replay.promotion_status != PromotionStatus.READY:
        replay.promotion_status = evaluate_promotion(replay)
    if replay.promotion_status != PromotionStatus.READY:
        raise HTTPException(400, "Patch does not meet promotion thresholds")

    patch = queue.patches.get(trace_id)
    if not patch:
        assessment = queue.assessments.get(trace_id)
        ft = assessment.failure_type.value if hasattr(assessment, "failure_type") else "hallucination"
        patch = build_patch_for_failure(ft, trace_id)

    version_tag = body.version_tag or f"v-{trace_id[:8]}"
    apply_result = apply_patch(patch, version_tag)

    trace = get_trace(trace_id)
    verify_result = None
    if trace:
        try:
            verify_result = asyncio.run(verify_after_apply(trace))
        except Exception as exc:
            import logging
            logging.getLogger("tracefix").warning("verify_after_apply failed: %s", exc)
        dataset_name = os.environ.get(
            "TRACEFIX_REGRESSION_DATASET", "tracefix-regression-failures"
        )
        if os.environ.get("TRACEFIX_DEMO_MODE", "0") != "1":
            add_regression_example(
                dataset_name,
                trace.user_input,
                metadata={"trace_id": trace_id, "version_tag": version_tag},
            )

    replay.promotion_status = PromotionStatus.PROMOTED
    upsert_replay(replay)

    decision = DecisionLog(
        trace_id=trace_id,
        human_approved=True,
        promoted_version_tag=version_tag,
        rollback_pointer=apply_result.rollback_pointer,
        apply_result=apply_result,
        verify_trace_id=verify_result.trace_id if verify_result else "",
        verify_passed=verify_result.passed if verify_result else False,
        verify_result=verify_result,
    )
    upsert_decision(decision)

    return {
        "decision": decision.model_dump(mode="json"),
        "apply_result": apply_result.model_dump(mode="json"),
        "verify_result": verify_result.model_dump(mode="json") if verify_result else {},
    }


@app.post("/api/traces/{trace_id}/rollback")
def rollback_patch(trace_id: str, body: RollbackRequest) -> dict:
    queue = load_queue()
    decision = queue.decisions.get(trace_id)
    version_tag = body.version_tag
    if not version_tag and decision and hasattr(decision, "rollback_pointer"):
        version_tag = decision.rollback_pointer
    if not version_tag:
        raise HTTPException(400, "No rollback version specified")

    result = rollback_to_version(version_tag)
    return {
        "trace_id": trace_id,
        "rollback": result.model_dump(mode="json"),
    }


@app.get("/api/config")
def get_config() -> dict:
    return {
        "mode": "demo"
        if os.environ.get("TRACEFIX_DEMO_MODE", "0") == "1" or not _phoenix_configured()
        else "live",
        "phoenix_ui_base": os.environ.get("PHOENIX_UI_BASE_URL", "https://app.phoenix.arize.com"),
        "adk_web_url": os.environ.get("ADK_WEB_URL", "http://127.0.0.1:8000/dev-ui/"),
        "project_name": os.environ.get("PHOENIX_PROJECT_NAME", "tracefix-support-agent"),
        **llm_config_summary(),
    }


@app.post("/api/traces/{trace_id}/run_patched")
def run_patched_agent(trace_id: str) -> dict:
    """Run the support agent with the currently applied active_policy and return the new response."""
    trace = get_trace(trace_id)
    if not trace:
        raise HTTPException(404, "Trace not found")

    try:
        from run_support import run_turn

        result = asyncio.run(run_turn(trace.user_input, simulate_only=False))
    except Exception as exc:
        return {
            "error": str(exc),
            "user_input": trace.user_input,
            "agent_output": "",
            "scores": {},
            "avg_score": 0.0,
            "tool_sequence": [],
            "new_trace_id": "",
            "status": "error",
        }

    # agent_output is written to the queue inside run_turn; read it back
    new_trace = get_trace(result["trace_id"])
    agent_output = new_trace.agent_output if new_trace else ""

    # Include the active prompt so the UI can show what the agent saw
    try:
        from support_demo.prompt import get_active_instruction, read_overlay_if_exists
        active_instruction = get_active_instruction()
        overlay = read_overlay_if_exists()
    except Exception:
        active_instruction = ""
        overlay = ""

    eval_data = result.get("eval", {})
    return {
        "error": None,
        "user_input": trace.user_input,
        "agent_output": agent_output,
        "scores": eval_data.get("scores", {}),
        "avg_score": eval_data.get("avg_score", 0.0),
        "tool_sequence": result.get("tool_sequence", []),
        "new_trace_id": result.get("trace_id", ""),
        "status": result.get("status", "unknown"),
        "active_instruction": active_instruction,
        "overlay": overlay,
    }


@app.post("/api/demo/seed")
def seed_demo() -> dict:
    from demo.seeds import export_cached_queue, run_all_seeds

    results = asyncio.run(run_all_seeds())
    export_cached_queue()
    return {"seeded": len(results), "results": results}


if WEB_DIR.exists():
    app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")

    @app.get("/")
    def index() -> FileResponse:
        return FileResponse(
            WEB_DIR / "index.html",
            headers={"Cache-Control": "no-store"},
        )
