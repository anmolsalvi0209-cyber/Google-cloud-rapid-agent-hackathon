# TraceFix — Hackathon demo plan (submission)

Use this document for **live judging**, **pre-recorded video**, and **Devpost** walkthrough. Keep one terminal for `make serve`, a second for optional `adk web` / copilot CLI.

---

## One-sentence pitch

TraceFix closes the loop from **Phoenix traces → RCA → patch → replay → human promote → auto-apply + verify + regression capture**, so Gemini/ADK agents improve from their own failures.

---

## Judging story arc (2–3 minutes)

| Beat | What judges see | Why it matters |
|------|------------------|----------------|
| **Problem** | A refund agent can approve without `policy_lookup` | Real ops risk |
| **Observe** | Triage UI + Phoenix deep link, spans and eval scores | Arize / observability |
| **Diagnose** | Copilot (ADK + Phoenix MCP) or seeded RCA | Agent + MCP |
| **Prove** | Replay before/after | Measurable improvement |
| **Ship** | Promote → apply panel, verify, optional Phoenix prompt | Closed loop, not a dashboard |
| **Trust** | Rollback + version tags | Safe iteration |

---

## Pre-demo checklist (do this before judges or recording)

### Environment

1. **Repo & deps:** `make setup` (or `uv sync --extra dev`).
2. **`.env`** (copy from `.env.example` if needed):
   - `PHOENIX_API_KEY` + `PHOENIX_COLLECTOR_ENDPOINT` (or `PHOENIX_BASE_URL`) for **live** triage badge and MCP writes.
   - Gemini: `GOOGLE_API_KEY` / Vertex AI.
   - Optional: `TRACEFIX_DEMO_MODE=0` for real replay/verify (requires credentials).
3. **Node.js 18+** on `PATH` (Phoenix MCP uses `npx`; project default args pull `ajv` + `zod-to-json-schema` to avoid broken caches).
4. **Ports:** `8080` (triage UI), `8000` (ADK web if used). Stop conflicting processes.

### Data

5. **Fresh queue with only seeded failures** (recommended for a clean table):

   ```bash
   make demo-failures
   ```

   That re-seeds `seed-hallucinated_policy`, `seed-wrong_tool_order`, `seed-cost_overrun`. If you previously cleared the queue manually, run this to restore the three rows.

6. Confirm **`make serve`** → http://localhost:8080 shows **Live mode** when `PHOENIX_API_KEY` is set (or **demo** mode for offline narrative).

### Optional dry runs

7. **Replay** on `seed-hallucinated_policy` once; confirm promotion shows **ready** (or acceptable message in demo mode).
8. **Promote** once on a copy of the repo or after backup if you do not want persistent `data/active_policy/` changes during practice.

---

## Primary demo path (recommended: ~8 minutes live, ~3 min video subset)

### Act 1 — Triage console (2 min)

1. Start: `make serve` → open **http://localhost:8080**.
2. Point to **Live mode — Phoenix connected** (or explain demo mode if no key).
3. Open trace **`seed-hallucinated_policy`** (failed, ~57% score, hallucination / wrong tool route).
4. Read **user request** vs **agent output** — “approve refund without checking policy.”
5. Click **Investigate Phoenix** — in Phoenix, show **missing `policy_lookup`** in the span/tool story and evaluator / annotation context if available.

**Talking point:** Observability is not enough; you need a loop that turns traces into changes.

### Act 2 — Copilot / RCA (2 min) — pick one

**Option A — ADK Web (best for UI):**

```bash
make run-adk-web
# or: cd agent && uv run python run_adk_web.py
```

Open **http://127.0.0.1:8000/dev-ui/** → select **`tracefix_copilot`**. Prefer `make run-adk-web` over raw `adk web` (loads `.env`, fixes graph 404 shim).

**ADK copilot + Phoenix MCP caveats:**
- Demo failures (`make demo-failures` / **Seed demo failures**) use deterministic 32-char trace ids and are **exported to Phoenix** when `PHOENIX_API_KEY` is set — same ids as the triage UI. Re-seed if MCP `get-trace` misses after a fresh Phoenix project.
- Support agent OTLP → **`tracefix-support-agent`**; copilot OTLP → **`tracefix-copilot`**. Ask copilot to `list-traces` on the support project.
- Live runs export OTLP traces to Phoenix; the triage **Phoenix trace ID** is the 32-char OpenTelemetry id (not `seed-*`). Use the Investigation panel id with MCP `get-trace`, or `list-traces` on **`tracefix-support-agent`**.
- First MCP connect needs a warm `npx` cache; wait for `Phoenix MCP Server running on stdio` in the terminal before chatting.

**Option B — CLI (reliable if MCP UI is flaky):**

```bash
make run-copilot TRACE_ID=seed-hallucinated_policy
```

**Talking point:** Copilot uses **Phoenix MCP** at runtime to ground investigation in real project traces and artifacts.

### Act 3 — Replay (1 min)

1. Back in triage UI → **Replay** on `seed-hallucinated_policy`.
2. Show **before/after scores** and **`promotion_status: ready`** (or explain guardrails if not ready).

**Talking point:** Replay is the gate between “idea” and “ship.”

### Act 4 — Promote = auto-apply + verify (2–3 min)

1. Click **Promote patch** (human-in-the-loop approval).
2. Expand **Apply and verify status**:
   - **Local:** `data/active_policy/` (instruction overlay + tool routing).
   - **Phoenix:** prompt upsert / dataset example status (may show skipped or failed if MCP/key issues — narrate honestly).
   - **Verification:** post-apply run scores.
3. Optional: open Phoenix → prompt / dataset to show new version or regression row.
4. Optional: **Rollback** with the returned `version_tag` / stored pointer to prove reversibility.

**Talking point:** This is the differentiator: **apply + verify + version**, not only recommendations.

### Act 5 — Close (30 s)

- “Agents improve from their own traces; humans stay in control; Phoenix stays the system of record.”

---

## Video vs live

| Segment | Live demo | 3-minute video (`VIDEO_SCRIPT.md`) |
|---------|-----------|-------------------------------------|
| Hook + failure + Phoenix | Full | Compressed |
| Copilot | ADK web or CLI | Optional or 1 line |
| Replay | Full | Yes |
| Promote + panel | Full | Yes |
| Rollback | If time | Skip or one line |

Record **1080p**, **clear audio**, show **browser + terminal** split if possible.

---

## Failure modes & backups

| Issue | Backup |
|-------|--------|
| No `PHOENIX_API_KEY` | Demo mode + cached traces; say “with API key, same UI talks to Phoenix live.” |
| MCP / `npx` errors | Promote still updates **local** policy; mention Phoenix write as best-effort; fix Node LTS or clear `~/.npm/_npx` if needed. |
| LLM errors on verify | Explain `TRACEFIX_DEMO_MODE=1` simulates verify; live mode needs valid Gemini/gateway + model routing. |
| `make serve` crash | `uv run uvicorn api.main:app --host 0.0.0.0 --port 8080` from repo root. |

---

## Google Cloud deploy (judges)

See **[DEPLOY.md](DEPLOY.md)**. Quick path:

```bash
make deploy-apis
export GOOGLE_API_KEY=... PHOENIX_API_KEY=...
make deploy-secrets
make deploy-cloud-run
make deploy-agent-engine   # optional: support agent on Agent Runtime
```

Share the **Cloud Run URL** on Devpost; optional Agent Studio screenshot for Agent Platform.

---

## Submission artifacts checklist

- [ ] **Devpost** — paste or adapt `DEVPOST.md`; add 2–3 screenshots (triage, Phoenix, promote panel).
- [ ] **Video** — follow `VIDEO_SCRIPT.md` (≤ 3 min); upload unlisted/public per rules.
- [ ] **Repo** — README quickstart works; `.env.example` documents auth + Phoenix + MCP.
- [ ] **Optional** — Cloud Run URL if deployed (`README` Cloud Build section).

---

## Commands quick reference

```bash
make setup              # deps + suggest .env
make demo-failures      # seed triage queue
make serve              # http://localhost:8080
make run-adk-web             # http://127.0.0.1:8000/dev-ui/
make run-copilot TRACE_ID=seed-hallucinated_policy
```

---

## After the hackathon

- Point stakeholders at `README.md` architecture diagram and `data/active_policy/` for “where the live policy lives.”
- Extend evaluators or add real trace ingestion from your Phoenix project.
