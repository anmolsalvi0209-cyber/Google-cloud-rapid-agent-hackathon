# TraceFix — Google Cloud deployment

Two GCP surfaces for the hackathon **Google Cloud requirement**:

| Component | Platform | Command |
|-----------|----------|---------|
| Triage UI + API | **Cloud Run** | `make deploy-cloud-run` |
| Support ADK agent | **Agent Platform Runtime** | `make deploy-agent-engine` |
| Observability | **Phoenix Cloud** (Arize) | Configure via secrets / `.env` |

**Sandbox project:** `reference-container-wwc5t`  
**Do not commit API keys** — use Secret Manager for Cloud Run and local `.env` only.

---

## Prerequisites

```bash
gcloud auth login
gcloud auth application-default login
gcloud config set project reference-container-wwc5t
```

Install TraceFix deps:

```bash
make setup
uv sync --extra gcp   # Agent Engine deploy CLI deps
```

---

## Phase 1 — Secret Manager (one-time)

Export keys locally (never commit), then:

```bash
export GOOGLE_API_KEY='your-google-ai-studio-or-gemini-key'
export PHOENIX_API_KEY='your-phoenix-key'
./deploy/setup_secrets.sh
```

Creates/updates:

- `google-api-key`
- `phoenix-api-key`

Grant Cloud Run access:

```bash
./deploy/grant_cloud_run_secrets.sh
```

---

## Phase 2 — Cloud Run (triage console)

```bash
make deploy-cloud-run
# or: gcloud builds submit --config cloudbuild.yaml
```

After deploy:

```bash
gcloud run services describe tracefix --region=us-central1 --format='value(status.url)'
```

**Demo mode (default in `cloudbuild.yaml`):** pre-seeded failures, works without live LLM on promote verify.  
**Live mode:** set Cloud Run env `TRACEFIX_DEMO_MODE=0` and ensure secrets + `PHOENIX_COLLECTOR_ENDPOINT` are set.

Optional env updates (Console → Cloud Run → tracefix → Edit):

| Variable | Example |
|----------|---------|
| `TRACEFIX_DEMO_MODE` | `0` for live promote/verify |
| `PHOENIX_COLLECTOR_ENDPOINT` | `https://app.phoenix.arize.com/s/your-space` |
| `GEMINI_MODEL` | `gemini-3.5-flash` |

---

## Phase 3 — Agent Platform Runtime (support agent)

Deploy `support_demo` to **Vertex AI Agent Engine**:

```bash
make deploy-agent-engine
```

Uses `adk deploy agent_engine` with project/region from `.env`.  
On success, note the **reasoning engine resource name** in the CLI output.

Test in [Agent Studio](https://console.cloud.google.com/agent-platform/studio) (project `reference-container-wwc5t`).

**Copilot + Phoenix MCP** remain local (`make run-adk-web`) for demos; Agent Runtime does not host the triage FastAPI app or `npx` MCP.

---

## Phase 4 — Local dev aligned with GCP

`.env` should use Google mode for sandbox:

```env
GEMINI_AUTH_MODE=google
GOOGLE_API_KEY=...
GOOGLE_GENAI_USE_VERTEXAI=0
GOOGLE_CLOUD_PROJECT=reference-container-wwc5t
GOOGLE_CLOUD_LOCATION=global
GEMINI_MODEL=gemini-3.5-flash
```

Then:

```bash
make serve
make run-adk-web
make run MESSAGE='Check refund eligibility for CUST-77 on order ORD-1002.'
```

---

## Judge demo flow (cloud)

1. Open **Cloud Run URL** → triage UI  
2. **Seed demo failures** or use pre-seeded queue  
3. **Replay → Promote** on hallucinated_policy row  
4. Show **Phoenix** trace + prompt version  
5. Optional: **Agent Studio** screenshot — support agent on Agent Runtime  

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Cloud Build permission denied | Enable Cloud Build, Cloud Run, Secret Manager APIs; `roles/run.admin` |
| Agent Engine deploy fails | `uv sync --extra gcp`; enable `aiplatform.googleapis.com` |
| Promote verify fails on Cloud Run | `TRACEFIX_DEMO_MODE=1` for demo-only, or set `GOOGLE_API_KEY` secret |
| Ephemeral queue on Cloud Run | Expected — use demo mode or add GCS later |
