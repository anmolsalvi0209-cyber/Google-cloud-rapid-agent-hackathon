#!/usr/bin/env bash
set -euo pipefail

PROJECT="${GCP_PROJECT:-reference-container-wwc5t}"
gcloud config set project "$PROJECT"

APIS=(
  cloudbuild.googleapis.com
  run.googleapis.com
  secretmanager.googleapis.com
  artifactregistry.googleapis.com
  aiplatform.googleapis.com
  cloudtrace.googleapis.com
)

for api in "${APIS[@]}"; do
  gcloud services enable "$api" --project="$PROJECT"
  echo "Enabled $api"
done

echo "APIs enabled for ${PROJECT}"
