#!/usr/bin/env bash
# Create/update Secret Manager secrets from env vars (never commit keys).
set -euo pipefail

PROJECT="${GCP_PROJECT:-reference-container-wwc5t}"
gcloud config set project "$PROJECT"

_create_or_update() {
  local name="$1"
  local value="$2"
  if [[ -z "${value}" ]]; then
    echo "Skip $name (empty). Export the env var and re-run." >&2
    return 0
  fi
  if gcloud secrets describe "$name" --project="$PROJECT" &>/dev/null; then
    echo -n "$value" | gcloud secrets versions add "$name" --data-file=-
    echo "Updated secret: $name"
  else
    echo -n "$value" | gcloud secrets create "$name" --data-file=-
    echo "Created secret: $name"
  fi
}

_create_or_update "google-api-key" "${GOOGLE_API_KEY:-}"
_create_or_update "phoenix-api-key" "${PHOENIX_API_KEY:-}"

echo "Done. Run ./deploy/grant_cloud_run_secrets.sh next."
