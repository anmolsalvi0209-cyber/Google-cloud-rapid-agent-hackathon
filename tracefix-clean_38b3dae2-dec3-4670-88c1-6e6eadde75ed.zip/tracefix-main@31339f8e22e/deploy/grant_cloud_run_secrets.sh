#!/usr/bin/env bash
set -euo pipefail

PROJECT="${GCP_PROJECT:-reference-container-wwc5t}"
REGION="${GCP_REGION:-us-central1}"
SERVICE="${CLOUD_RUN_SERVICE:-tracefix}"

gcloud config set project "$PROJECT"

PROJECT_NUMBER="$(gcloud projects describe "$PROJECT" --format='value(projectNumber)')"
SA="${PROJECT_NUMBER}-compute@developer.gserviceaccount.com"

for secret in google-api-key phoenix-api-key; do
  gcloud secrets add-iam-policy-binding "$secret" \
    --member="serviceAccount:${SA}" \
    --role="roles/secretmanager.secretAccessor" \
    --project="$PROJECT" \
    --quiet || true
done

echo "Granted secretAccessor on google-api-key and phoenix-api-key to ${SA}"
echo "Cloud Run service: ${SERVICE} (${REGION})"
