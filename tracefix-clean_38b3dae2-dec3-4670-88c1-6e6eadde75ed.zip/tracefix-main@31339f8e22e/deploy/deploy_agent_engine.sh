#!/usr/bin/env bash
# Deploy support_demo to Vertex AI Agent Engine (Gemini Enterprise Agent Platform Runtime).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

PROJECT="${GOOGLE_CLOUD_PROJECT:-reference-container-wwc5t}"
REGION="${GOOGLE_CLOUD_LOCATION:-us-central1}"
DISPLAY="${AGENT_ENGINE_DISPLAY_NAME:-TraceFix Support Agent}"

# Agent Engine rejects reserved env names (e.g. PORT). Build a deploy-only env file.
ENV_DEPLOY="$(mktemp)"
trap 'rm -f "$ENV_DEPLOY"' EXIT
if [[ -f "$ROOT/.env" ]]; then
  grep -v -E '^(PORT|ADK_WEB_URL)=' "$ROOT/.env" >"$ENV_DEPLOY" || true
fi

echo "Deploying support_demo → Agent Engine (project=${PROJECT}, region=${REGION})"

cd agent

ARGS=(
  deploy agent_engine
  --project="$PROJECT"
  --region="$REGION"
  --display_name="$DISPLAY"
  --description="TraceFix refund support agent with instrumented tools and Phoenix OTLP"
  --env_file="$ENV_DEPLOY"
  --otel_to_cloud
  support_demo
)

if [[ -n "${GOOGLE_API_KEY:-}" ]]; then
  ARGS+=(--api_key="$GOOGLE_API_KEY")
fi

if ! uv run adk "${ARGS[@]}"; then
  echo "Agent Engine deploy failed." >&2
  exit 1
fi

echo "Deploy complete. Open Agent Studio for project ${PROJECT}."
