# TraceFix demo video script (≤ 3 minutes)

Full walkthrough, backups, and submission checklist: **[DEMO_PLAN.md](DEMO_PLAN.md)**.

**Prereq (5 s on screen or voiceover):** `make setup` → `.env` with Phoenix + Gemini (or say “demo mode” if offline). `make demo-failures` → `make serve` → http://localhost:8080

---

## 0:00 — Hook (15 s)

“A refund agent approved a refund **without** `policy_lookup`. How do we catch that, prove a fix, and **ship** it—with the human still in the loop?”

---

## 0:15 — Failure in triage (25 s)

- Triage UI (`make serve` → http://localhost:8080)
- Open **`seed-hallucinated_policy`** — failed, ~57%, hallucination / wrong tool route
- Show **user message** vs **agent output** (approve without policy)

---

## 0:40 — Phoenix evidence (25 s)

- **Investigate Phoenix** (deep link)
- Highlight: `order_lookup` present, **`policy_lookup` missing**; groundedness / eval story

---

## 1:05 — Copilot RCA (20 s) — pick one path

**Path A:** `cd agent && uv run adk web` → http://127.0.0.1:8000/dev-ui/ → **`tracefix_copilot`**, one turn tying failure to missing policy check.

**Path B (faster):** `make run-copilot TRACE_ID=seed-hallucinated_policy` — show terminal: classification + patch intent (tool routing / prompt).

*Voiceover:* Copilot uses **Phoenix MCP** at runtime to ground the investigation.

---

## 1:25 — Replay proof (20 s)

- **Replay** on the same seed trace
- Show scorecard / **`promotion_status: ready`** (or narrate guardrails if demo limits scores)

---

## 1:45 — Promote = apply + verify (45 s)

- **Promote patch**
- **Apply and verify** panel:
  - **Local:** `data/active_policy/` updated
  - **Phoenix:** prompt / dataset line (ok, skipped, or failed—be honest if MCP hiccups)
  - **Verification** after apply
- One line optional: **Rollback** restores prior snapshot if judges ask

---

## 2:30 — Close (15 s)

“TraceFix: Phoenix traces → RCA → replay → **you promote** → we **apply**, **verify**, and **record** the version. Agents learn from their own failures.”

---

## B-roll (if trimming to 2:30)

Cut copilot path B; keep Phoenix + Replay + Promote panel.
