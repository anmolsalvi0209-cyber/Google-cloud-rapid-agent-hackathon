# TraceFix

**A self-improving reliability copilot for Gemini agents** — built for the Google Cloud Rapid Agent Hackathon (Arize track).

TraceFix turns Arize Phoenix observability into an active improvement loop: it watches Gemini/ADK agent traces, detects failures, explains root cause, proposes prompt/tool-routing fixes, replays failed executions, and **automatically applies approved patches** to the running agent (local policy + Phoenix prompt version).

## Architecture

```
User task → Gemini ADK support agent → OpenInference → Phoenix Cloud
                                              ↓
Phoenix MCP ← TraceFix copilot → patch proposal → replay → promote applies fix → verify → triage UI
```

## Stack

- **Task agent:** Google ADK + Gemini (`support_demo`)
- **Copilot:** Google ADK + Phoenix MCP (`@arizeai/phoenix-mcp`)
- **Tracing:** OpenInference + `phoenix.otel.register`
- **Evals:** task success, groundedness, tool correctness, cost discipline
- **UI:** minimal triage console (FastAPI + static web) + ADK web + Phoenix deep links
- **Deploy:** Google Cloud Run

## Quickstart (10 minutes)

### Prerequisites

- Python 3.10–3.12
- [uv](https://docs.astral.sh/uv/)
- Node.js (for Phoenix MCP via `npx`)
- Google auth: `GOOGLE_API_KEY` or Vertex AI
- Phoenix Cloud API key

### Setup

```bash
cp .env.example .env
# Edit .env: PHOENIX_API_KEY, PHOENIX_COLLECTOR_ENDPOINT, and Gemini auth (see below)

make setup
```

### Gemini auth modes

Set variables in `.env`:

| Mode | Variables |
|------|-----------|
| API key (default) | `GOOGLE_API_KEY` |
| Vertex AI | `GOOGLE_GENAI_USE_VERTEXAI=1` + `GOOGLE_CLOUD_PROJECT` |

### Run support agent (traced)

```bash
make run MESSAGE='Customer Alex requests refund for order ORD-1001 — item defective.'
```

Open Phoenix → project `tracefix-support-agent` → confirm LLM and tool spans.

### Seed demo failures

```bash
make demo-failures
```

Populates the triage queue with three failure modes:
- `hallucinated_policy` — refund without policy lookup
- `wrong_tool_order` — customer history before order lookup
- `cost_overrun` — excessive model calls

### Hackathon demo (judges + video)

- **[DEMO_PLAN.md](DEMO_PLAN.md)** — full walkthrough, pre-demo checklist, failure backups, submission checklist.
- **[VIDEO_SCRIPT.md](VIDEO_SCRIPT.md)** — ≤ 3 minute shot list aligned with that plan.

### Start triage console

```bash
make serve
# Open http://localhost:8080
```

### Run copilot (Phoenix MCP)

```bash
make run-copilot TRACE_ID=seed-hallucinated_policy
```

### ADK web (support + copilot)

```bash
make run-adk-web
# Open http://127.0.0.1:8000/dev-ui/
```

Uses `agent/run_adk_web.py` (loads `.env`, adds `/dev/build_graph_image` shim for ADK Web). Raw `adk web` still works but may 404 on graph previews.

Requires Node.js 18+ on PATH for copilot Phoenix MCP (`npx`).

