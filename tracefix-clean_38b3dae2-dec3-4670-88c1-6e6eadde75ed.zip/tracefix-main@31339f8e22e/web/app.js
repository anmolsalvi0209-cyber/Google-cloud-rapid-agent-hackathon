let selectedTraceId = null;
let config = {};

// ── Config ───────────────────────────────────────────────
async function fetchConfig() {
  const res = await fetch("/api/config");
  config = await res.json();
  const banner = document.getElementById("mode-banner");
  banner.textContent = config.mode === "live"
    ? "Live mode — Phoenix connected"
    : "Demo mode — cached traces";
  banner.className = `banner ${config.mode}`;
  document.getElementById("phoenix-link").href = config.phoenix_ui_base || "#";
  document.getElementById("adk-link").href = config.adk_web_url || "#";
}

// ── Queue ─────────────────────────────────────────────────
async function loadQueue() {
  const res = await fetch("/api/queue");
  const queue = await res.json();
  const tbody = document.getElementById("queue-body");
  tbody.innerHTML = "";

  for (const trace of queue.traces || []) {
    const tr = document.createElement("tr");
    const labels = (trace.failure_labels || []).join(", ") || "—";
    const score = ((trace.eval_score || 0) * 100).toFixed(0);
    tr.innerHTML = `
      <td><code title="${trace.trace_id}">${trace.trace_id.slice(0, 12)}…</code></td>
      <td class="status-${trace.status}">${trace.status}</td>
      <td>${labels}</td>
      <td>${score}%</td>
      <td>$${(trace.estimated_cost || 0).toFixed(4)}</td>
      <td>${(trace.latency_ms || 0).toFixed(0)}ms</td>
      <td>
        <button class="link-btn" data-trace="${trace.trace_id}">Investigate</button>
        ${trace.phoenix_url
          ? `<a class="link-btn" href="${trace.phoenix_url}" target="_blank">Phoenix ↗</a>`
          : ""}
      </td>`;
    tbody.appendChild(tr);
  }

  tbody.querySelectorAll("button[data-trace]").forEach((btn) => {
    btn.addEventListener("click", () => showDetail(btn.dataset.trace));
  });
}

// ── Helpers ───────────────────────────────────────────────
function scoreBar(score) {
  const pct = Math.round((score || 0) * 100);
  const color = score >= 0.7 ? "#22c55e" : score >= 0.4 ? "#f59e0b" : "#ef4444";
  return `
    <div class="score-row">
      <div class="score-bar-bg">
        <div class="score-bar-fill" style="width:${pct}%;background:${color}"></div>
      </div>
      <span class="score-val">${pct}%</span>
    </div>`;
}

function deltaHtml(val) {
  if (val === undefined || val === null) return "<span class='muted'>—</span>";
  const pct = Math.round(Math.abs(val) * 100);
  if (val > 0.005) return `<span class="delta-up">+${pct}%</span>`;
  if (val < -0.005) return `<span class="delta-down">-${pct}%</span>`;
  return `<span class="muted">0%</span>`;
}

function isEmpty(obj) {
  return !obj || Object.keys(obj).length === 0;
}

function setStatus(msg, type = "info") {
  const el = document.getElementById("action-status");
  el.textContent = msg;
  el.className = `action-status status-${type}`;
  el.classList.remove("hidden");
}

function clearStatus() {
  document.getElementById("action-status").classList.add("hidden");
}

// ── Detail panel ──────────────────────────────────────────
async function showDetail(traceId) {
  selectedTraceId = traceId;
  clearStatus();

  const res = await fetch(`/api/traces/${traceId}`);
  const data = await res.json();

  const trace      = data.trace      || {};
  const assessment = data.assessment || {};
  const patch      = data.patch      || {};
  const replay     = data.replay     || {};
  const decision   = data.decision   || {};

  document.getElementById("detail-panel").classList.remove("hidden");
  document.getElementById("trace-id-full").textContent = traceId;

  // 1. Original interaction
  document.getElementById("original-input").textContent  = trace.user_input  || "(no input recorded)";
  document.getElementById("original-output").textContent = trace.agent_output || "(no output recorded)";

  // 2. Failure analysis — labels
  const labelHtml = (trace.failure_labels || [])
    .map(l => `<span class="tag tag-fail">${l.replace(/_/g, " ")}</span>`)
    .join(" ");
  document.getElementById("failure-labels").innerHTML = labelHtml || "<span class='muted'>none</span>";

  // Root cause — plain sentence, not JSON
  document.getElementById("rca-text").textContent =
    assessment.natural_language_rca || assessment.failure_type || "(no root cause recorded)";

  // Eval score bars
  const scores = assessment.evaluator_scores || {};
  const scoreHtml = Object.entries(scores).map(([k, v]) =>
    `<div class="score-label">${k.replace(/_/g, " ")}</div>${scoreBar(v)}`
  ).join("");
  document.getElementById("eval-scores").innerHTML =
    scoreHtml || "<span class='muted'>No scores available</span>";

  // 3. Proposed fix
  document.getElementById("patch-type").textContent    = patch.patch_type              || "—";
  document.getElementById("patch-target").textContent  = patch.target_prompt_or_tool   || "—";
  document.getElementById("patch-summary").textContent = patch.diff_summary            || "—";
  document.getElementById("patch-content").textContent = patch.patched_content         || "—";

  const riskEl = document.getElementById("patch-risk");
  riskEl.textContent = patch.risk_level || "—";
  riskEl.className = `tag tag-risk-${patch.risk_level || "unknown"}`;

  const expected = patch.expected_metric_change || {};
  document.getElementById("patch-expected").textContent =
    Object.entries(expected).map(([k, v]) => `${k.replace(/_/g, " ")}: ${v}`).join("  ·  ") || "—";

  // 4. Replay table
  const replaySection = document.getElementById("replay-section");
  if (!isEmpty(replay) && replay.promotion_status) {
    const metrics = ["task_success", "groundedness", "tool_correctness", "cost_discipline"];
    const rows = metrics.map(m => {
      const before = replay.baseline_scores?.[m];
      const after  = replay.patched_scores?.[m];
      const delta  = replay.score_delta?.[m];
      const bPct = before !== undefined ? Math.round(before * 100) + "%" : "—";
      const aPct = after  !== undefined ? Math.round(after  * 100) + "%" : "—";
      return `<tr>
        <td>${m.replace(/_/g, " ")}</td>
        <td>${bPct}</td>
        <td>${aPct}</td>
        <td>${deltaHtml(delta)}</td>
      </tr>`;
    }).join("");
    document.getElementById("replay-scores").innerHTML = rows;

    const latMs = replay.latency_delta_ms;
    document.getElementById("replay-latency").textContent =
      latMs !== undefined ? `${latMs > 0 ? "+" : ""}${Math.round(latMs)}ms` : "—";

    const costD = replay.cost_delta;
    document.getElementById("replay-cost").textContent =
      costD !== undefined ? `${costD >= 0 ? "+" : ""}$${costD.toFixed(6)}` : "—";

    const statusEl = document.getElementById("replay-status");
    const st = replay.promotion_status || "unknown";
    statusEl.textContent = st;
    statusEl.className = `tag tag-${st === "ready" ? "ready" : st === "promoted" ? "promoted" : "fail"}`;

    replaySection.classList.remove("hidden");
  } else {
    replaySection.classList.add("hidden");
  }

  // 5. Apply panel (only after promote)
  const applyPanel = document.getElementById("apply-panel");
  if (!isEmpty(decision) && decision.human_approved && decision.apply_result) {
    document.getElementById("apply-version").textContent  = decision.promoted_version_tag || "—";
    document.getElementById("apply-rollback").textContent = decision.rollback_pointer      || "—";
    const vr = decision.verify_result;
    document.getElementById("apply-verify").textContent = vr
      ? (vr.passed ? "✅ Passed" : `❌ Failed (score ${Math.round((vr.avg_score || 0) * 100)}%)`)
      : (decision.verify_passed ? "✅ Passed" : "—");
    applyPanel.classList.remove("hidden");
  } else {
    applyPanel.classList.add("hidden");
  }

  document.getElementById("detail-panel").scrollIntoView({ behavior: "smooth" });
}

// ── Button handlers ───────────────────────────────────────
document.getElementById("seed-btn").addEventListener("click", async () => {
  const btn = document.getElementById("seed-btn");
  btn.textContent = "Seeding…";
  btn.disabled = true;
  await fetch("/api/demo/seed", { method: "POST" });
  await loadQueue();
  btn.textContent = "Seed demo failures";
  btn.disabled = false;
});

document.getElementById("replay-btn").addEventListener("click", async () => {
  if (!selectedTraceId) return;
  const btn = document.getElementById("replay-btn");
  btn.textContent = "Replaying…";
  btn.disabled = true;
  setStatus("Running replay comparison…", "info");

  const res = await fetch(`/api/traces/${selectedTraceId}/replay`, { method: "POST" });
  btn.textContent = "Replay";
  btn.disabled = false;

  if (res.ok) {
    setStatus("Replay complete — scores updated.", "success");
    await showDetail(selectedTraceId);
  } else {
    const err = await res.json().catch(() => ({}));
    setStatus(`Replay failed: ${err.detail || "unknown error"}`, "error");
  }
});

document.getElementById("promote-btn").addEventListener("click", async () => {
  if (!selectedTraceId) return;
  const btn = document.getElementById("promote-btn");
  btn.textContent = "Promoting…";
  btn.disabled = true;
  setStatus("Applying patch and running verification…", "info");

  const res = await fetch(`/api/traces/${selectedTraceId}/promote`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ approved: true, version_tag: `v-${selectedTraceId.slice(0, 8)}` }),
  });

  btn.textContent = "Promote patch";
  btn.disabled = false;

  if (res.ok) {
    const payload = await res.json();
    const vr = payload.verify_result || {};
    const passed = vr.passed;
    setStatus(
      passed
        ? `✅ Promoted as ${payload.decision?.promoted_version_tag}. Verification passed.`
        : `⚠️ Promoted as ${payload.decision?.promoted_version_tag}. Verification score: ${Math.round((vr.avg_score || 0) * 100)}% (below threshold — patch applied, monitor results).`,
      passed ? "success" : "warn"
    );
    await showDetail(selectedTraceId);
    await loadQueue();
  } else {
    let errMsg = "Promotion rejected";
    try { errMsg = (await res.json()).detail || errMsg; } catch (_) {}
    setStatus(`❌ ${errMsg}`, "error");
  }
});

document.getElementById("run-patched-btn").addEventListener("click", async () => {
  if (!selectedTraceId) return;
  const btn = document.getElementById("run-patched-btn");
  const panel = document.getElementById("live-run-panel");
  const loading = document.getElementById("live-run-loading");
  const result = document.getElementById("live-run-result");
  const errPanel = document.getElementById("live-run-error");

  btn.textContent = "Running…";
  btn.disabled = true;
  panel.classList.remove("hidden");
  loading.classList.remove("hidden");
  result.classList.add("hidden");
  errPanel.classList.add("hidden");
  panel.scrollIntoView({ behavior: "smooth" });

  const res = await fetch(`/api/traces/${selectedTraceId}/run_patched`, { method: "POST" });
  loading.classList.add("hidden");
  btn.textContent = "▶ Run agent with patch";
  btn.disabled = false;

  if (!res.ok) {
    errPanel.classList.remove("hidden");
    document.getElementById("live-run-error-text").textContent = `HTTP ${res.status} — server error`;
    return;
  }

  const data = await res.json();

  if (data.error) {
    errPanel.classList.remove("hidden");
    document.getElementById("live-run-error-text").textContent = data.error;
    return;
  }

  // Show result
  result.classList.remove("hidden");

  // Revised prompt
  document.getElementById("live-run-prompt").textContent =
    data.active_instruction || "(prompt not available)";

  // Status badge
  const badgeEl = document.getElementById("live-run-status-badge");
  const st = data.status || "unknown";
  badgeEl.innerHTML = `<span class="tag tag-${st === "passed" ? "ready" : "fail"}" style="margin-bottom:0.5rem;display:inline-block">
    ${st === "passed" ? "✅ passed" : "❌ " + st}
  </span>`;

  // New response text
  document.getElementById("live-run-output").textContent =
    data.agent_output || "(no response recorded)";

  // Tools called
  document.getElementById("live-run-tools").textContent =
    (data.tool_sequence || []).join(" → ") || "none";

  // Trace ID link
  document.getElementById("live-run-trace-id").textContent =
    (data.new_trace_id || "").slice(0, 16) + "…";

  // Scores vs original — get original from current detail view
  const currentRes = await fetch(`/api/traces/${selectedTraceId}`);
  const currentData = await currentRes.json();
  const originalScores = currentData.assessment?.evaluator_scores || {};
  const newScores = data.scores || {};

  const metrics = ["task_success", "groundedness", "tool_correctness", "cost_discipline"];
  const rows = metrics.map(m => {
    const before = originalScores[m];
    const after  = newScores[m];
    const delta  = (after !== undefined && before !== undefined) ? after - before : null;
    return `<tr>
      <td>${m.replace(/_/g, " ")}</td>
      <td>${before !== undefined ? Math.round(before * 100) + "%" : "—"}</td>
      <td>${after  !== undefined ? Math.round(after  * 100) + "%" : "—"}</td>
      <td>${deltaHtml(delta)}</td>
    </tr>`;
  }).join("");
  document.getElementById("live-run-scores").innerHTML = rows;

  const avg = data.avg_score || 0;
  const avgEl = document.getElementById("live-run-avg");
  avgEl.textContent = Math.round(avg * 100) + "%";
  avgEl.style.color = avg >= 0.75 ? "var(--success)" : avg >= 0.4 ? "var(--warn)" : "var(--danger)";

  // Reload queue so the new trace appears
  await loadQueue();
});

document.getElementById("rollback-btn").addEventListener("click", async () => {
  if (!selectedTraceId) return;
  const btn = document.getElementById("rollback-btn");
  btn.textContent = "Rolling back…";
  btn.disabled = true;
  setStatus("Rolling back policy…", "info");

  const res = await fetch(`/api/traces/${selectedTraceId}/rollback`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({}),
  });

  btn.textContent = "Rollback";
  btn.disabled = false;

  if (res.ok) {
    setStatus("✅ Policy rolled back to previous version.", "success");
    await showDetail(selectedTraceId);
  } else {
    let errMsg = "Rollback failed";
    try { errMsg = (await res.json()).detail || errMsg; } catch (_) {}
    setStatus(`❌ ${errMsg}`, "error");
  }
});

// ── Init ─────────────────────────────────────────────────
fetchConfig().then(loadQueue);
